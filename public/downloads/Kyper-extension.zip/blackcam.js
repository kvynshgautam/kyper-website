// GhostTyper: fake black camera for Snapchat Web (runs in the page itself).
// It stays OFF all the time and is switched on only while Streak Saver is working.
(() => {
  if (window.__rgBlackCam) return;
  window.__rgBlackCam = true;
  const md = navigator.mediaDevices;
  if (!md || !md.getUserMedia) return;

  const origGUM = md.getUserMedia.bind(md);
  const origEnum = md.enumerateDevices ? md.enumerateDevices.bind(md) : null;
  const realStreams = new WeakSet();
  const swapped = new Map(); // <video> -> its real stream
  let on = false, fake = null, timer = null;

  function makeFake() {
    if (fake && fake.getVideoTracks().some((t) => t.readyState === "live")) return fake;
    const w = 1280, h = 720;
    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext("2d");
    const draw = () => { ctx.fillStyle = "#000"; ctx.fillRect(0, 0, w, h); };
    draw();
    clearInterval(timer);
    timer = setInterval(draw, 100);
    fake = canvas.captureStream(10);
    return fake;
  }

  md.getUserMedia = async function (constraints) {
    if (on && constraints && constraints.video) {
      const f = makeFake().clone();
      if (constraints.audio) {
        try { (await origGUM({ audio: constraints.audio })).getAudioTracks().forEach((t) => f.addTrack(t)); } catch (e) {}
      }
      return f;
    }
    const s = await origGUM(constraints);
    try { if (s.getVideoTracks().length) realStreams.add(s); } catch (e) {}
    return s;
  };

  if (origEnum) {
    md.enumerateDevices = async function () {
      const list = await origEnum();
      if (on && !list.some((d) => d.kind === "videoinput")) {
        list.push({ deviceId: "rg-black-cam", kind: "videoinput", label: "Camera", groupId: "rg", toJSON() { return this; } });
      }
      return list;
    };
  }

  // If the camera is already open with the real webcam, show black in that video instead.
  function swapOn() {
    document.querySelectorAll("video").forEach((v) => {
      const s = v.srcObject;
      if (s && realStreams.has(s) && !swapped.has(v)) {
        swapped.set(v, s);
        v.srcObject = makeFake().clone();
        v.play && v.play().catch(() => {});
      }
    });
  }
  function swapOff() {
    swapped.forEach((orig, v) => {
      try { if (v.isConnected && orig.active) { v.srcObject = orig; v.play && v.play().catch(() => {}); } } catch (e) {}
    });
    swapped.clear();
  }

  document.addEventListener("rg-blackcam", (e) => {
    on = e.detail === "on";
    if (on) swapOn(); else swapOff();
  });
})();
