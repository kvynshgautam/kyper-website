const $ = (id) => document.getElementById(id);

function openTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.toggle("active", b.getAttribute("data-tab") === tabId));
  document.querySelectorAll(".tab-pane").forEach((p) => p.classList.toggle("active", p.id === tabId));
  const sw = $("saveWrap");
  if (sw) sw.style.display = tabId === "tab-plan" ? "none" : "block";
}
let didInitTab = false;
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => openTab(btn.getAttribute("data-tab")));
});
document.querySelectorAll(".go-plan").forEach((btn) => {
  btn.addEventListener("click", () => openTab("tab-plan"));
});
if ($("openGuide")) {
  $("openGuide").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
}

const INFO = {
  groq:      { model: "openai/gpt-oss-120b", ph: "gsk_...", hint: "Free & ultra-fast. Get a key at console.groq.com/keys." },
  gemini:    { model: "gemini-3.8-flash",    ph: "AIza...", hint: "Get a free key at aistudio.google.com → Get API key." },
  anthropic: { model: "claude-haiku-5-5",    ph: "sk-ant-...", hint: "Get a key at platform.claude.com → Settings → API keys." },
  openai:    { model: "gpt-4o-mini",         ph: "sk-...",  hint: "Get a key at platform.openai.com → API keys." },
  custom:    { model: "",                    ph: "API key (leave empty for local models)", hint: "Any OpenAI-compatible service: OpenRouter, DeepSeek, Ollama, LM Studio…" },
};

let state = { provider: "groq", keys: {}, models: {}, baseUrl: "" };
let current = "groq";
let isPro = false;

const PLANS = (typeof GT_CONFIG !== "undefined" && Array.isArray(GT_CONFIG.PLANS) && GT_CONFIG.PLANS.length)
  ? GT_CONFIG.PLANS
  : [
      { id: "monthly", label: "Monthly Pro (30 Days)", short: "Monthly · ₹99", amount: 99, days: 30 },
      { id: "lifetime", label: "Lifetime Pro (One-Time)", short: "Lifetime · ₹499", amount: 499, days: 0 },
    ];
let selectedPlan = PLANS[0];
let compressedShot = "";

if (typeof GT_CONFIG !== "undefined" && GT_CONFIG.PRICE_LABEL) {
  $("buyPro").textContent = `👑 Upgrade to KYPER Pro (${GT_CONFIG.PRICE_LABEL})`;
}
$("upiIdText").textContent = (typeof GT_CONFIG !== "undefined" && GT_CONFIG.UPI_ID) || "yourname@upi";
$("upiPayeeName").textContent = (typeof GT_CONFIG !== "undefined" && GT_CONFIG.UPI_NAME) || "KYPER";
if (typeof GT_CONFIG !== "undefined" && GT_CONFIG.UPI_QR_IMAGE) {
  $("qrImg").src = GT_CONFIG.UPI_QR_IMAGE;
  $("qrWrap").style.display = "block";
}

function renderPlanPicker() {
  const wrap = $("planPick");
  wrap.innerHTML = "";
  for (const pl of PLANS) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "plan-opt" + (pl.id === selectedPlan.id ? " active" : "");
    b.textContent = pl.short || `${pl.label} · ₹${pl.amount}`;
    b.onclick = () => {
      selectedPlan = pl;
      renderPlanPicker();
    };
    wrap.appendChild(b);
  }
  $("upiAmtLabel").textContent = `₹${selectedPlan.amount}`;
}
renderPlanPicker();

function compressScreenshot(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read image file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Invalid image file."));
      img.onload = () => {
        const maxW = 700;
        const maxH = 1200;
        let w = img.width;
        let h = img.height;
        const scale = Math.min(1, maxW / w, maxH / h);
        w = Math.max(1, Math.round(w * scale));
        h = Math.max(1, Math.round(h * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        let dataUrl = canvas.toDataURL("image/jpeg", 0.68);
        if (dataUrl.length > 380000) dataUrl = canvas.toDataURL("image/jpeg", 0.48);
        if (dataUrl.length > 430000) return reject(new Error("Image too large. Please crop and try again."));
        resolve(dataUrl);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function render(provider) {
  current = provider;
  const info = INFO[provider] || INFO.groq;
  $("provider").value = provider;
  $("apiKey").value = state.keys[provider] || "";
  $("apiKey").placeholder = info.ph;
  $("model").value = state.models[provider] || "";
  $("model").placeholder = info.model || "model name";
  $("keyHint").textContent = info.hint + " Stored only in your browser.";
  $("baseWrap").style.display = provider === "custom" ? "block" : "none";
  $("baseUrl").value = state.baseUrl || "";
}

function captureInputs() {
  state.keys[current] = $("apiKey").value.trim();
  state.models[current] = $("model").value.trim();
  state.baseUrl = $("baseUrl").value.trim();
}

function showAuto() {
  const on = isPro && $("autoOn").checked;
  $("autoState").textContent = on ? "ON. Replies are sent automatically in WhatsApp Web." : "OFF. Nothing is sent automatically.";
  $("autoState").className = on ? "on" : "";
}

function renderPlanUI(p) {
  isPro = !!(p && p.isPro);
  const pill = $("planPill");
  const nav = document.querySelector(".tabs-nav");
  const planBtn = nav && nav.querySelector('[data-tab="tab-plan"]');
  if (nav && planBtn) {
    if (isPro) nav.appendChild(planBtn);
    else nav.prepend(planBtn);
  }
  if (!didInitTab) {
    didInitTab = true;
    openTab(isPro ? "tab-auto" : "tab-plan");
  }
  if (isPro) {
    pill.textContent = "👑 PRO";
    pill.className = "plan-pill pro";
    $("freeCard").style.display = "none";
    $("upiPayBox").style.display = "none";
    $("pendingBox").style.display = "none";
    $("proCard").style.display = "block";
    $("activateBox").style.display = "none";
    $("proBadgeLabel").textContent = (p.label || "PRO").toUpperCase();
    const masked = p.licenseKey ? p.licenseKey.replace(/^([A-Z]+)-[A-Z0-9]+-/, "$1-****-") : "";
    const exp = p.expiresAt ? "Valid till " + new Date(p.expiresAt).toLocaleDateString() : "Lifetime Access";
    $("proDetails").textContent = `Key: ${masked} · ${exp}. Unlimited replies & all Pro features unlocked!`;
    $("autoLockBanner").style.display = "none";
    $("autoPanels").classList.remove("locked-panel");
    $("useOwnKey").checked = !!p.useOwnKey;
    $("ownKeyPanel").style.display = p.useOwnKey ? "block" : "none";
    if (p.autoUnlocked) say("🎉 Payment Approved! KYPER Pro unlocked!");
  } else {
    const limit = (p && p.limit) || 15;
    const rem = p && typeof p.remaining === "number" ? p.remaining : limit;
    pill.textContent = "FREE";
    pill.className = "plan-pill";
    $("freeCard").style.display = "block";
    $("proCard").style.display = "none";
    $("activateBox").style.display = "block";
    $("quotaText").textContent = `${rem} / ${limit} left today`;
    $("quotaText").style.color = rem <= 3 ? "#ef5350" : "#3fb68b";
    $("quotaFill").style.width = Math.max(0, Math.min(100, Math.round((rem / limit) * 100))) + "%";
    $("autoLockBanner").style.display = "flex";
    $("autoPanels").classList.add("locked-panel");
    $("useOwnKey").checked = false;
    $("ownKeyPanel").style.display = "none";

    const pay = p && p.payment;
    if (pay && (pay.status === "pending" || pay.status === "rejected")) {
      $("pendingBox").style.display = "block";
      $("pendingId").textContent = pay.id || "UPI";
      if (pay.status === "rejected") {
        $("pendingBox").className = "panel pending-box rejected";
        $("pendingTitle").textContent = "❌ Payment Verification Failed";
        $("pendingDesc").textContent = `Reason: ${pay.rejectReason || "Payment not received / invalid screenshot."}`;
        $("reuploadPay").style.display = "block";
      } else {
        $("pendingBox").className = "panel pending-box";
        $("pendingTitle").textContent = "⏳ Payment Verification Pending";
        $("pendingDesc").textContent = `Submitted for ${pay.planLabel || "Pro"} (₹${pay.amount || 99}). Once confirmed, Pro unlocks automatically!`;
        $("reuploadPay").style.display = "none";
      }
    } else {
      $("pendingBox").style.display = "none";
    }
  }
  showAuto();
}

function loadPlan(refresh, cb) {
  chrome.runtime.sendMessage({ action: "getPlan", refresh: !!refresh }, (r) => {
    if (!chrome.runtime.lastError && r && r.ok) {
      renderPlanUI(r);
      if (cb) cb(r);
    } else if (cb) {
      cb(null);
    }
  });
}

function say(text, bad) {
  $("msg").style.color = bad ? "#ef5350" : "#3fb68b";
  $("msg").textContent = text;
  setTimeout(() => ($("msg").textContent = ""), 3500);
}

$("buyPro").onclick = () => {
  $("upiPayBox").style.display = "block";
  $("upiPayBox").scrollIntoView({ behavior: "smooth", block: "nearest" });
};

$("closeUpiBox").onclick = () => {
  $("upiPayBox").style.display = "none";
};

$("reuploadPay").onclick = () => {
  $("upiPayBox").style.display = "block";
  $("upiPayBox").scrollIntoView({ behavior: "smooth", block: "nearest" });
};

$("copyUpi").onclick = async () => {
  const upi = $("upiIdText").textContent.trim();
  try {
    await navigator.clipboard.writeText(upi);
    $("copyUpi").textContent = "✓ Copied!";
    setTimeout(() => ($("copyUpi").textContent = "📋 Copy UPI"), 2000);
  } catch {
    say("UPI ID: " + upi);
  }
};

$("payShot").onchange = async () => {
  const file = $("payShot").files && $("payShot").files[0];
  const pm = $("payMsg");
  compressedShot = "";
  $("shotPreview").style.display = "none";
  if (!file) return;
  pm.style.color = "#828fa7";
  pm.textContent = "Processing screenshot...";
  try {
    compressedShot = await compressScreenshot(file);
    $("shotPreview").src = compressedShot;
    $("shotPreview").style.display = "block";
    pm.style.color = "#3fb68b";
    pm.textContent = `✓ Screenshot ready (${Math.round(compressedShot.length / 1024)} KB)`;
  } catch (e) {
    pm.style.color = "#ef5350";
    pm.textContent = "✗ " + (e.message || "Could not read screenshot.");
  }
};

$("submitPay").onclick = () => {
  const name = $("payName").value.trim();
  const utr = $("payUtr").value.trim();
  const pm = $("payMsg");
  if (!name) { pm.style.color = "#ef5350"; pm.textContent = "Please enter your name."; return; }
  if (!compressedShot) { pm.style.color = "#ef5350"; pm.textContent = "Please attach your UPI payment screenshot first."; return; }
  $("submitPay").disabled = true;
  $("submitPay").textContent = "Uploading Proof...";
  pm.style.color = "#828fa7";
  pm.textContent = "Sending payment proof for verification...";
  chrome.runtime.sendMessage(
    { action: "submitPayment", name, utr, planId: selectedPlan.id, screenshot: compressedShot },
    (r) => {
      $("submitPay").disabled = false;
      $("submitPay").textContent = "✅ Submit Payment Proof";
      if (chrome.runtime.lastError || !r) {
        pm.style.color = "#ef5350";
        pm.textContent = "Extension error. Please reload and try again.";
        return;
      }
      if (r.ok) {
        pm.style.color = "#3fb68b";
        pm.textContent = "✓ Submitted! Waiting for payment confirmation.";
        $("upiPayBox").style.display = "none";
        $("payName").value = "";
        $("payUtr").value = "";
        $("payShot").value = "";
        $("shotPreview").style.display = "none";
        compressedShot = "";
        loadPlan(false);
      } else {
        pm.style.color = "#ef5350";
        pm.textContent = "✗ " + (r.error || "Upload failed.");
      }
    }
  );
};

$("checkPayStatus").onclick = () => {
  const btn = $("checkPayStatus");
  const pm = $("pendingMsg");
  btn.disabled = true;
  btn.textContent = "Checking...";
  pm.style.color = "#828fa7";
  pm.textContent = "Checking with server...";
  loadPlan(true, (r) => {
    btn.disabled = false;
    btn.textContent = "🔄 Check Approval Status";
    if (!r) { pm.style.color = "#ef5350"; pm.textContent = "Could not reach server."; return; }
    if (r.isPro) {
      pm.style.color = "#3fb68b";
      pm.textContent = "✓ Approved! Pro is now active.";
    } else if (r.payment && r.payment.status === "rejected") {
      pm.style.color = "#ef5350";
      pm.textContent = "Payment was not approved. Please check reason above.";
    } else {
      pm.style.color = "#f3d690";
      pm.textContent = "Still pending verification — check again shortly!";
    }
  });
};

$("activateLic").onclick = () => {
  const key = $("licKey").value.trim();
  const lm = $("licMsg");
  if (!key) { lm.style.color = "#ef5350"; lm.textContent = "Please paste your License Key first."; return; }
  $("activateLic").disabled = true;
  $("activateLic").textContent = "Checking...";
  lm.style.color = "#828fa7";
  lm.textContent = "Verifying license key with server...";
  chrome.runtime.sendMessage({ action: "activateLicense", licenseKey: key }, (r) => {
    $("activateLic").disabled = false;
    $("activateLic").textContent = "Activate";
    if (chrome.runtime.lastError || !r) {
      lm.style.color = "#ef5350";
      lm.textContent = "Could not reach background worker. Reload extension.";
      return;
    }
    if (r.ok) {
      lm.style.color = "#3fb68b";
      lm.textContent = "✓ KYPER Pro Activated! Enjoy unlimited access.";
      $("licKey").value = "";
      loadPlan(false);
    } else {
      lm.style.color = "#ef5350";
      lm.textContent = "✗ " + (r.error || "Invalid license key.");
    }
  });
};

$("useOwnKey").onchange = () => {
  if (!isPro) {
    $("useOwnKey").checked = false;
    $("ownKeyPanel").style.display = "none";
    say("👑 Custom API Key is a PRO feature!", true);
    openTab("tab-plan");
    return;
  }
  const on = $("useOwnKey").checked;
  $("ownKeyPanel").style.display = on ? "block" : "none";
  chrome.storage.local.set({ useOwnKey: on });
};

$("testCloud").onclick = () => {
  const resEl = $("cloudTestRes");
  $("testCloud").disabled = true;
  $("testCloud").textContent = "Testing...";
  resEl.style.color = "#828fa7";
  resEl.textContent = "Pinging KYPER Cloud...";
  chrome.runtime.sendMessage({ action: "test", mode: "cloud" }, (r) => {
    $("testCloud").disabled = false;
    $("testCloud").textContent = "⚡ Test Cloud Connection";
    if (chrome.runtime.lastError || !r) { resEl.style.color = "#ef5350"; resEl.textContent = "Extension error."; return; }
    if (r.ok) { resEl.style.color = "#3fb68b"; resEl.textContent = `✓ Connected to ${r.model} (${r.ms}ms)`; }
    else { resEl.style.color = "#ef5350"; resEl.textContent = "✗ " + (r.error || "Failed"); }
  });
};

$("stOn").onchange = () => { if (isPro) chrome.storage.local.set({ snStreakOn: $("stOn").checked }); };
$("stDry").onchange = () => chrome.storage.local.set({ snStreakDry: $("stDry").checked });
$("autoOn").onchange = () => {
  if (!isPro) { $("autoOn").checked = false; openTab("tab-plan"); return; }
  chrome.storage.local.set({ autoOn: $("autoOn").checked });
  showAuto();
};

chrome.storage.local.get([
  "provider", "keys", "models", "baseUrl", "apiKey", "about", "tone", "chatTones",
  "lang", "myName", "myStyle", "styleMemory", "gender", "emoMode", "angerResp",
  "autoOn", "autoScope", "autoMin", "autoMax", "autoPerHour", "autoDayCap", "autoCfgV",
  "snStreakOn", "snStreakDry", "snStreakEvery", "snStreakMax", "useOwnKey"
], (d) => {
  d = d || {};
  if (d.autoCfgV !== 4) {
    const nv = { autoPerHour: 30, autoDayCap: 300, autoMin: 1, autoMax: 3, autoCfgV: 4 };
    Object.assign(d, nv);
    chrome.storage.local.set(nv);
  }
  $("autoOn").checked = !!d.autoOn;
  $("autoScope").value = d.autoScope === "all" ? "all" : "chats";
  $("autoMin").value = d.autoMin || 1;
  $("autoMax").value = d.autoMax || 3;
  $("autoPerHour").value = d.autoPerHour || 30;
  $("autoDayCap").value = d.autoDayCap || 300;
  $("stOn").checked = !!d.snStreakOn;
  $("stDry").checked = d.snStreakDry !== false;
  $("stEvery").value = d.snStreakEvery || 30;
  $("stMax").value = d.snStreakMax || 5;
  $("useOwnKey").checked = !!d.useOwnKey;
  $("ownKeyPanel").style.display = d.useOwnKey ? "block" : "none";
  state.provider = d.provider || "groq";
  state.keys = d.keys || {};
  state.models = d.models || {};
  state.baseUrl = d.baseUrl || "";
  if (!state.keys.anthropic && d.apiKey) state.keys.anthropic = d.apiKey;
  $("about").value = d.about || "";
  $("myName").value = d.myName || "";
  $("myStyle").value = d.myStyle || "";
  const memCount = Array.isArray(d.styleMemory) ? d.styleMemory.length : 0;
  $("learnedInfo").textContent = memCount
    ? `Auto-learned from ${memCount} of your real messages.`
    : "Auto-learns your short words from chats (Pro).";
  const ctCount = d.chatTones && typeof d.chatTones === "object" ? Object.keys(d.chatTones).length : 0;
  $("chatTonesInfo").textContent = ctCount
    ? `${ctCount} chat${ctCount > 1 ? "s have" : " has"} custom mood saved.`
    : "No per-chat moods saved yet.";
  $("gender").value = ["male", "female"].includes(d.gender) ? d.gender : "auto";
  $("emoMode").value = d.emoMode === "on" ? "on" : "off";
  $("angerResp").value = d.angerResp === "match" ? "match" : "calm";
  if (d.tone) $("tone").value = d.tone;
  if (d.lang) $("lang").value = d.lang;
  render(state.provider);
  loadPlan(true);
});

$("clearStyle").onclick = () => {
  chrome.storage.local.remove("styleMemory", () => {
    $("learnedInfo").textContent = "Learned style reset.";
    say("Learned style cleared.");
  });
};

$("clearChatTones").onclick = () => {
  chrome.storage.local.remove("chatTones", () => {
    $("chatTonesInfo").textContent = "All per-chat moods cleared.";
    say("Per-chat moods reset to default.");
  });
};

$("provider").onchange = () => {
  captureInputs();
  render($("provider").value);
  $("testResult").textContent = "";
};

$("testApi").onclick = async () => {
  captureInputs();
  const resEl = $("testResult");
  const btn = $("testApi");
  if (current === "custom") {
    let origin;
    try { origin = new URL(state.baseUrl).origin + "/*"; }
    catch { resEl.style.color = "#ef5350"; resEl.textContent = "Invalid Base URL."; return; }
    try {
      const ok = await chrome.permissions.request({ origins: [origin] });
      if (!ok) { resEl.style.color = "#ef5350"; resEl.textContent = "Permission denied for " + origin; return; }
    } catch (e) { resEl.style.color = "#ef5350"; resEl.textContent = e.message; return; }
  }
  btn.disabled = true;
  btn.textContent = "Testing...";
  resEl.style.color = "#828fa7";
  resEl.textContent = "Pinging " + current + "...";
  chrome.runtime.sendMessage(
    { action: "test", provider: current, key: state.keys[current] || "", model: state.models[current] || "", baseUrl: state.baseUrl || "" },
    (r) => {
      btn.disabled = false;
      btn.textContent = "⚡ Test Own API Connection";
      if (chrome.runtime.lastError || !r) { resEl.style.color = "#ef5350"; resEl.textContent = "Extension error."; return; }
      if (r.ok) { resEl.style.color = "#3fb68b"; resEl.textContent = `✓ Connected! Model: ${r.model} (${r.ms}ms)`; }
      else { resEl.style.color = "#ef5350"; resEl.textContent = "✗ " + (r.error || "Failed"); }
    }
  );
};

$("save").onclick = async () => {
  captureInputs();
  state.provider = current;
  const useOwnKey = isPro && $("useOwnKey").checked;

  if (useOwnKey && current === "custom") {
    let origin;
    try { origin = new URL(state.baseUrl).origin + "/*"; }
    catch { return say("Please enter a valid Base URL.", true); }
    try {
      const ok = await chrome.permissions.request({ origins: [origin] });
      if (!ok) return say("Permission denied for " + origin, true);
    } catch (e) { return say("Cannot use this URL: " + e.message, true); }
  }

  chrome.storage.local.set(
    {
      useOwnKey,
      provider: state.provider,
      keys: state.keys,
      models: state.models,
      baseUrl: state.baseUrl,
      about: $("about").value.trim(),
      myName: $("myName").value.trim(),
      myStyle: $("myStyle").value.trim(),
      gender: $("gender").value,
      tone: $("tone").value,
      emoMode: $("emoMode").value,
      angerResp: $("angerResp").value,
      lang: $("lang").value,
      autoScope: $("autoScope").value,
      autoMin: Math.max(1, Number($("autoMin").value) || 1),
      autoMax: Math.max(1, Number($("autoMax").value) || 3),
      autoPerHour: Math.max(1, Number($("autoPerHour").value) || 30),
      autoDayCap: Math.max(1, Number($("autoDayCap").value) || 300),
      snStreakEvery: Math.max(5, Number($("stEvery").value) || 30),
      snStreakMax: Math.max(1, Math.min(20, Number($("stMax").value) || 5)),
    },
    () => say("Settings saved.")
  );
};
