// =====================================================================
//  GhostTyper Public Edition — Developer Configuration
//  Bas yahan apna Cloudflare Worker URL aur apni UPI ID daalo!
// =====================================================================
const GT_CONFIG = {
  // 1. Cloudflare / Render Backend Link:
  CLOUD_URL: "https://kyper.onrender.com",

  // 2. Apni Personal ya Business UPI ID yahan daalo (jaise "kavyansh@okaxis" ya "ghosttyper@ybl"):
  UPI_ID: "kavyanshgautam1@ptyes",

  // 3. UPI app par jo naam dikhta hai:
  UPI_NAME: "Kavyansh Gautam",

  // 4. Optional: Agar apna PhonePe/Paytm/GPay ka asli QR photo dikhana ho,
  //    toh us photo ko isi "ghosttyper-public" folder mein "upi-qr.png" naam se save karo
  //    aur neeche "" ki jagah "upi-qr.png" likh do.
  UPI_QR_IMAGE: "",

  // 5. Pro Plans (amount ₹ mein; server/worker.js ke PLAN_CATALOG se match hona chahiye)
  PLANS: [
    { id: "monthly", label: "1 Month Pro (30 Days)", short: "1 Mo · ₹99", amount: 99, days: 30 },
    { id: "quarterly", label: "3 Months Pro (90 Days)", short: "3 Mo · ₹249", amount: 249, days: 90 },
    { id: "semi_annual", label: "6 Months Pro (180 Days)", short: "6 Mo · ₹449", amount: 449, days: 180 },
    { id: "annual", label: "1 Year VIP (365 Days)", short: "1 Yr · ₹799", amount: 799, days: 365 },
    { id: "lifetime", label: "Lifetime VIP (Forever)", short: "👑 Lifetime · ₹1,499", amount: 1499, days: 0 },
  ],

  // Free plan daily replies limit (server/worker.js ke FREE_DAILY_LIMIT se match hona chahiye)
  FREE_DAILY_LIMIT: 15,

  // Upgrade button par dikhne wala price text
  PRICE_LABEL: "₹99/mo",
};
