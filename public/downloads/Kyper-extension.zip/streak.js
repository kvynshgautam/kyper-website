// GhostTyper: Streak Saver for Snapchat Web (EXPERIMENTAL).
// Finds friends whose streak is about to end (hourglass next to the name) and sends them a black snap.
// TEST MODE (default) does every step except the very last "Send" click.
(() => {
  if (window.__rgStreak) return;
  window.__rgStreak = true;

  const FONT = '"Segoe UI","Helvetica Neue",Arial,sans-serif';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vis = (el) => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
  };
  const HG = /[\u231B\u23F3]/; // hourglass emojis
  const CLICKABLE = 'button, [role="button"], a, [role="menuitem"], [role="checkbox"], [role="option"], [role="listitem"], [role="radio"], label, [tabindex]';
  const MIN_GAP = 6 * 3600 * 1000; // never send the same friend twice within 6 hours

  const S = { on: false, dry: true, every: 30, max: 5, sent: {}, running: false, stop: false, log: [], timer: null, last: 0 };
  let lastUser = 0;
  for (const t of ["pointerdown", "keydown", "wheel"]) addEventListener(t, (e) => { if (e.isTrusted) lastUser = Date.now(); }, true);

  // ---------------- small UI ----------------
  const tab = document.createElement("button");
  tab.textContent = "Streaks";
  Object.assign(tab.style, {
    position: "fixed", right: "0", bottom: "290px", zIndex: 99998, padding: "8px 12px", fontSize: "12px", fontWeight: "600",
    fontFamily: FONT, cursor: "pointer", background: "#0b1120", color: "#e8cc85", border: "1px solid #c9a24b", borderRight: "0",
    borderRadius: "10px 0 0 10px", transform: "translateX(calc(100% - 22px))", opacity: ".4", transition: "transform .25s ease, opacity .25s ease",
  });
  const panel = document.createElement("div");
  Object.assign(panel.style, {
    position: "fixed", right: "24px", bottom: "340px", zIndex: 99999, width: "290px", padding: "12px 14px", borderRadius: "10px",
    background: "#0b1120", color: "#e8ebf2", borderLeft: "3px solid #c9a24b", fontSize: "12.5px", lineHeight: "1.45", fontFamily: FONT,
    boxShadow: "0 6px 18px rgba(0,0,0,.45)", display: "none",
  });
  const title = document.createElement("div");
  title.textContent = "Streak Saver (experimental)";
  Object.assign(title.style, { fontWeight: "700", color: "#e8cc85", marginBottom: "4px" });
  const modeEl = document.createElement("div");
  const statusEl = document.createElement("div");
  Object.assign(statusEl.style, { margin: "6px 0 8px", color: "#c4cada", wordBreak: "break-word", minHeight: "34px" });
  const bar = document.createElement("div");
  Object.assign(bar.style, { display: "flex", flexWrap: "wrap", gap: "6px" });
  const mk = (label) => {
    const b = document.createElement("button");
    b.textContent = label;
    Object.assign(b.style, { padding: "4px 10px", fontSize: "11px", fontWeight: "600", cursor: "pointer", fontFamily: FONT,
      background: "transparent", color: "#e8cc85", border: "1px solid #c9a24b", borderRadius: "6px" });
    return b;
  };
  const bOnOff = mk("Turn ON"), bScan = mk("Scan"), bRun = mk("Run now"), bStop = mk("Stop"), bDbg = mk("Copy debug");
  bar.append(bOnOff, bScan, bRun, bStop, bDbg);
  panel.append(title, modeEl, statusEl, bar);
  document.body.append(tab, panel);

  let hov = false;
  tab.addEventListener("mouseenter", () => { hov = true; tab.style.transform = "translateX(0)"; tab.style.opacity = "1"; });
  tab.addEventListener("mouseleave", () => { hov = false; if (panel.style.display === "none") { tab.style.transform = "translateX(calc(100% - 22px))"; tab.style.opacity = S.on ? "1" : ".4"; } });
  tab.addEventListener("click", () => { panel.style.display = panel.style.display === "none" ? "block" : "none"; });

  function paint() {
    modeEl.textContent = (S.on ? "ON" : "OFF") + " | " + (S.dry ? "TEST mode (does not press the final Send)" : "LIVE mode (really sends)");
    modeEl.style.color = S.dry ? "#8893a9" : "#e8cc85";
    bOnOff.textContent = S.on ? "Turn OFF" : "Turn ON";
    tab.style.borderColor = S.on ? "#3fb68b" : "#c9a24b";
    tab.style.opacity = S.on ? "1" : ".4";
  }
  const setStatus = (t) => { statusEl.textContent = t; };
  function log(m) {
    S.log.push(new Date().toLocaleTimeString() + " " + m);
    S.log = S.log.slice(-80);
    console.log("[Streak Saver]", m);
    setStatus(m);
    try { chrome.storage.local.set({ snStreakLog: S.log }); } catch {}
  }

  // ---------------- helpers ----------------
  function realClick(el) {
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    for (const t of ["pointerover", "pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      const C = t.startsWith("pointer") ? PointerEvent : MouseEvent;
      el.dispatchEvent(new C(t, o));
    }
  }
  const attrLabel = (el) => [el.getAttribute("aria-label"), el.getAttribute("title"), el.getAttribute("data-testid"), el.getAttribute("alt")].filter(Boolean).join(" | ");
  const shortText = (el) => { const t = (el.innerText || "").trim(); return t.length <= 32 ? t : ""; };
  const labelOf = (el) => (attrLabel(el) + " | " + shortText(el)).trim();
  const clickables = () => [...document.querySelectorAll(CLICKABLE)].filter(vis);
  const findBy = (re, bad) => clickables().filter((el) => { const l = labelOf(el); return re.test(l) && !(bad && bad.test(l)); });
  async function waitFor(fn, ms = 8000, step = 250) {
    const end = Date.now() + ms;
    for (;;) {
      let v; try { v = fn(); } catch { v = null; }
      if (v) return v;
      if (Date.now() > end || S.stop) return null;
      await sleep(step);
    }
  }
  const camOn = (on) => { try { document.dispatchEvent(new CustomEvent("rg-blackcam", { detail: on ? "on" : "off" })); } catch {} };
  const bigVideo = () => [...document.querySelectorAll("video")].filter(vis).sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0] || null;

  // ---------------- finding friends with a streak about to end ----------------
  function rowOf(el) {
    let p = el;
    for (let i = 0; i < 10 && p && p !== document.body; i++, p = p.parentElement) {
      const r = p.getBoundingClientRect();
      if (r.height >= 44 && r.height <= 130 && r.width >= 160 && r.left < innerWidth * 0.5) return p;
    }
    return null;
  }
  const STATUS = /^(received|sent|opened|delivered|new snap|new chat|new message|tap to|typing|replay|streak|you|\d+[smhd]?\b|\u00b7)/i;
  function nameOf(row) {
    const lines = (row.innerText || "").split("\n").map((s) => s.replace(HG, "").replace(/[\u200e\u200f]/g, "").trim()).filter(Boolean);
    for (const l of lines) {
      if (l.length > 40 || !/\p{L}/u.test(l) || STATUS.test(l)) continue;
      return l;
    }
    return "";
  }
  function scan() {
    const hits = new Set();
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) if (HG.test(n.nodeValue) && n.parentElement) hits.add(n.parentElement);
    document.querySelectorAll("[alt],[aria-label],[title]").forEach((el) => {
      if (HG.test((el.getAttribute("alt") || "") + (el.getAttribute("aria-label") || "") + (el.getAttribute("title") || ""))) hits.add(el);
    });
    const names = new Map();
    for (const el of hits) {
      if (!vis(el)) continue;
      const row = rowOf(el);
      const name = row && nameOf(row);
      if (name && !names.has(name)) names.set(name, row);
    }
    return [...names.keys()];
  }

  // ---------------- the steps for ONE friend ----------------
  async function openCamera() {
    if (bigVideo()) return true;
    const cam = findBy(/camera/i, /roll|flip|switch|permission|off|disable/i)[0];
    if (!cam) throw new Error("Could not find the Camera button (use 'Copy debug' and send it to the developer)");
    realClick(cam);
    const v = await waitFor(bigVideo, 9000);
    if (!v) throw new Error("Camera did not open (no video appeared)");
    await sleep(800);
    return true;
  }
  function captureButton() {
    const named = findBy(/take|capture|shutter/i, /send|story|lens|filter/i)[0];
    if (named) return named;
    const v = bigVideo();
    if (!v) return null;
    const vr = v.getBoundingClientRect();
    const cx = vr.left + vr.width / 2;
    const round = clickables().filter((el) => {
      const r = el.getBoundingClientRect();
      const ratio = r.width / r.height;
      return r.width >= 36 && r.width <= 140 && ratio > 0.8 && ratio < 1.25 && r.top > vr.top + vr.height * 0.5 && r.left >= vr.left - 40 && r.right <= vr.right + 40;
    });
    round.sort((a, b) => {
      const da = Math.abs(a.getBoundingClientRect().left + a.getBoundingClientRect().width / 2 - cx);
      const db = Math.abs(b.getBoundingClientRect().left + b.getBoundingClientRect().width / 2 - cx);
      return da - db;
    });
    return round[0] || null;
  }
  const norm = (s) => String(s || "").replace(/[\u200e\u200f]/g, "").replace(/\s+/g, " ").trim().toLowerCase();

  function closeAll() {
    for (let i = 0; i < 2; i++) {
      for (const t of ["keydown", "keyup"]) document.dispatchEvent(new KeyboardEvent(t, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true }));
    }
    const x = findBy(/^(close|cancel|back|discard|dismiss)\b|\b(close|discard)\b/i, /send/i)[0];
    if (x) realClick(x);
  }

  async function sendBlack(friend) {
    log("Working on: " + friend);
    camOn(true);
    await sleep(300);
    await openCamera();

    // remember where the name already is (the chat list) so we pick the one inside the recipient picker
    const before = new Set([...document.querySelectorAll("span,div,p,h1,h2,h3,h4")].filter((e) => norm(e.textContent) === norm(friend)));

    const cap = await waitFor(captureButton, 6000);
    if (!cap) throw new Error("Could not find the capture (round) button");
    realClick(cap);
    log("Snap taken, looking for 'Send To'...");

    const sendTo = await waitFor(() => findBy(/^send to\b|\bsend to\b/i)[0], 7000);
    if (!sendTo) throw new Error("'Send To' did not appear after taking the snap");
    realClick(sendTo);
    await sleep(900);

    const nameEl = await waitFor(() => [...document.querySelectorAll("span,div,p,h1,h2,h3,h4")].find((e) => vis(e) && !before.has(e) && norm(e.textContent) === norm(friend)), 6000);
    if (!nameEl) throw new Error("Could not find '" + friend + "' in the Send To list");
    let row = nameEl.closest('[role="listitem"], [role="option"], [role="checkbox"], label, li') || nameEl;
    let clk = nameEl.closest(CLICKABLE) || row;
    realClick(clk);
    await sleep(700);

    // verify exactly one recipient is selected, and that it is this friend
    let root = row;
    for (let i = 0; i < 12 && root.parentElement; i++) {
      root = root.parentElement;
      if (findBy(/^send$|^send\b(?! to)/i).some((b) => root.contains(b))) break;
    }
    const checked = [...root.querySelectorAll('[aria-checked="true"], input:checked, [aria-selected="true"]')].filter((e) => vis(e) || e.tagName === "INPUT");
    const ok = checked.length === 1 && (row.contains(checked[0]) || checked[0].contains(nameEl));
    log("Selected recipients found: " + checked.length + (ok ? " (this friend only)" : " (not sure)"));

    if (S.dry) {
      log("TEST OK for " + friend + ": all steps worked. Final Send NOT pressed (test mode).");
      closeAll();
      await sleep(1200);
      return "tested";
    }
    if (!ok) { closeAll(); throw new Error("Could not confirm that only " + friend + " is selected, so nothing was sent"); }

    const send = await waitFor(() => findBy(/^send$|^send\b(?! to)/i, /send to/i).find((b) => root.contains(b)) || findBy(/^send$/i)[0], 5000);
    if (!send) { closeAll(); throw new Error("Could not find the final Send button"); }
    realClick(send);
    const gone = await waitFor(() => !findBy(/send to/i).length, 9000);
    if (!gone) throw new Error("Not sure the snap was sent (the Send To screen is still open)");
    S.sent[friend] = Date.now();
    try { chrome.storage.local.set({ snStreakSent: S.sent }); } catch {}
    log("SENT black snap to " + friend);
    await sleep(1500);
    return "sent";
  }

  // ---------------- a full run ----------------
  async function runOnce(manual) {
    if (S.running) return log("Already running.");
    if (!manual && Date.now() - lastUser < 20000) return log("You are using the page, will try again later.");
    S.running = true; S.stop = false; S.last = Date.now();
    let fails = 0, done = 0;
    try {
      const all = scan();
      const due = all.filter((n) => !S.sent[n] || Date.now() - S.sent[n] > MIN_GAP).slice(0, S.max);
      if (!all.length) return log("No friend with an hourglass found right now.");
      log("Streaks ending soon: " + all.join(", ") + (S.dry ? " (test mode)" : ""));
      for (const f of due) {
        if (S.stop) break;
        try { await sendBlack(f); done++; fails = 0; }
        catch (e) { fails++; log("FAILED for " + f + ": " + e.message); closeAll(); await sleep(1500); if (fails >= 2) { log("Stopping after 2 failures."); break; } }
        await sleep(3500 + Math.random() * 3500);
      }
      if (done) log("Run finished: " + done + (S.dry ? " tested." : " sent."));
    } finally {
      camOn(false);
      S.running = false;
    }
  }

  function schedule() {
    clearTimeout(S.timer);
    if (!S.on) return;
    S.timer = setTimeout(async () => { try { await runOnce(false); } catch (e) { log("Error: " + e.message); } schedule(); }, Math.max(5, S.every) * 60 * 1000);
  }

  // ---------------- debug dump (so the selectors can be fixed fast if Snapchat differs) ----------------
  async function copyDebug() {
    const rows = clickables().slice(0, 120).map((el) => {
      const r = el.getBoundingClientRect();
      return el.tagName.toLowerCase() + (el.getAttribute("role") ? "[role=" + el.getAttribute("role") + "]" : "") +
        " | label=" + (attrLabel(el) || "-") + " | text=" + (shortText(el).replace(/\n/g, " / ") || "-") +
        " | " + Math.round(r.left) + "," + Math.round(r.top) + " " + Math.round(r.width) + "x" + Math.round(r.height);
    });
    const v = bigVideo();
    const txt = ["GhostTyper Streak Saver debug", location.href, "mode=" + (S.dry ? "test" : "live"),
      "hourglass friends: " + (scan().join(", ") || "none"), "video visible: " + !!v, "--- log ---", ...S.log.slice(-25), "--- clickable elements ---", ...rows].join("\n");
    try { await navigator.clipboard.writeText(txt); log("Debug info copied. Paste it to the developer."); }
    catch { const ta = document.createElement("textarea"); ta.value = txt; ta.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); log("Debug info copied. Paste it to the developer."); }
  }

  // ---------------- buttons + settings (PRO gated) ----------------
  S.pro = false;
  bOnOff.onclick = () => {
    if (!S.pro) return log("👑 Streak Saver is a PRO feature. Activate Pro in GhostTyper popup.");
    S.on = !S.on; try { chrome.storage.local.set({ snStreakOn: S.on }); } catch {} paint(); schedule(); log(S.on ? "Streak Saver ON. Checks every " + S.every + " min. Keep this tab open." : "Streak Saver OFF.");
  };
  bScan.onclick = () => { const n = scan(); log(n.length ? "Hourglass friends: " + n.join(", ") : "No friend with an hourglass found (is the chat list visible on the left?)"); };
  bRun.onclick = () => {
    if (!S.pro) return log("👑 Streak Saver is a PRO feature. Activate Pro in GhostTyper popup.");
    runOnce(true).catch((e) => log("Error: " + e.message));
  };
  bStop.onclick = () => { S.stop = true; log("Stopping..."); };
  bDbg.onclick = () => copyDebug();

  const KEYS = ["snStreakOn", "snStreakDry", "snStreakEvery", "snStreakMax", "snStreakSent", "snStreakLog", "plan", "licenseKey", "proExpiresAt"];
  const load = (d) => {
    d = d || {};
    S.pro = d.plan === "pro" && !!d.licenseKey && (!d.proExpiresAt || Date.now() <= d.proExpiresAt);
    S.on = S.pro && !!d.snStreakOn;
    S.dry = d.snStreakDry !== false; // test mode unless the user switched it off
    S.every = Math.max(5, Number(d.snStreakEvery) || 30);
    S.max = Math.max(1, Math.min(20, Number(d.snStreakMax) || 5));
    if (d.snStreakSent) S.sent = d.snStreakSent;
    paint(); schedule();
  };
  try {
    chrome.storage.local.get(KEYS, (d) => { load(d); if (S.on) setTimeout(() => runOnce(false).catch(() => {}), 25000); });
    chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ["snStreakOn", "snStreakDry", "snStreakEvery", "snStreakMax", "plan", "licenseKey", "proExpiresAt"].some((k) => k in ch)) chrome.storage.local.get(KEYS, load); });
  } catch { paint(); }
  paint();
  setStatus("Hover the right edge, press Scan to see which friends have an hourglass.");
})();
