(() => {
  if (window.__waSmartReply) return;
  window.__waSmartReply = true;

  // ---- which site are we on? ----
  const host = location.hostname;
  const PLATFORM =
    host === "web.whatsapp.com" ? "whatsapp" :
    host === "mail.google.com" ? "gmail" :
    /(^|\.)outlook\.(live|office|office365)\.com$/.test(host) ? "outlook" :
    host.endsWith("instagram.com") ? "instagram" :
    host.endsWith("snapchat.com") ? "snapchat" :
    (host.endsWith("facebook.com") || host.endsWith("messenger.com")) ? "facebook" : "";
  if (!PLATFORM) return;

  // Icons are built with DOM calls, not innerHTML: Gmail, Instagram and Facebook block innerHTML (Trusted Types)
  const NS = "http://www.w3.org/2000/svg";
  const mkIcon = (d, stroked) => {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "14");
    svg.setAttribute("height", "14");
    svg.style.flex = "none";
    const p = document.createElementNS(NS, "path");
    p.setAttribute("d", d);
    p.setAttribute("fill-rule", "evenodd");
    if (stroked) {
      svg.setAttribute("fill", "none");
      svg.setAttribute("stroke", "currentColor");
      svg.setAttribute("stroke-width", "2");
      svg.setAttribute("stroke-linecap", "round");
      svg.setAttribute("stroke-linejoin", "round");
    } else {
      svg.setAttribute("fill", "currentColor");
    }
    svg.appendChild(p);
    return svg;
  };

  const mkKyperLogo = (size = 18, opts = {}) => {
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 120 120");
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
    svg.style.flex = "none";
    svg.style.display = "inline-block";
    svg.style.verticalAlign = "middle";

    const defs = document.createElementNS(NS, "defs");
    const uid = "kyp_" + Math.random().toString(36).slice(2, 7);

    // Shield base gradient
    const shieldGrad = document.createElementNS(NS, "linearGradient");
    shieldGrad.id = uid + "_s";
    shieldGrad.setAttribute("x1", "0"); shieldGrad.setAttribute("y1", "0");
    shieldGrad.setAttribute("x2", "1"); shieldGrad.setAttribute("y2", "1");
    const s1 = document.createElementNS(NS, "stop"); s1.setAttribute("offset", "0%"); s1.setAttribute("stop-color", opts.onYellow ? "#0f172a" : "#181b2c");
    const s2 = document.createElementNS(NS, "stop"); s2.setAttribute("offset", "100%"); s2.setAttribute("stop-color", opts.onYellow ? "#020617" : "#06080f");
    shieldGrad.append(s1, s2);

    // Rim gradient
    const rimGrad = document.createElementNS(NS, "linearGradient");
    rimGrad.id = uid + "_r";
    rimGrad.setAttribute("x1", "0"); rimGrad.setAttribute("y1", "0");
    rimGrad.setAttribute("x2", "1"); rimGrad.setAttribute("y2", "1");
    const r1 = document.createElementNS(NS, "stop"); r1.setAttribute("offset", "0%"); r1.setAttribute("stop-color", opts.onYellow ? "#facc15" : "#ffffff");
    const r2 = document.createElementNS(NS, "stop"); r2.setAttribute("offset", "50%"); r2.setAttribute("stop-color", "#a78bfa");
    const r3 = document.createElementNS(NS, "stop"); r3.setAttribute("offset", "100%"); r3.setAttribute("stop-color", "#06b6d4");
    rimGrad.append(r1, r2, r3);

    // Stem gradient
    const stemGrad = document.createElementNS(NS, "linearGradient");
    stemGrad.id = uid + "_k";
    stemGrad.setAttribute("x1", "0"); stemGrad.setAttribute("y1", "0");
    stemGrad.setAttribute("x2", "0"); stemGrad.setAttribute("y2", "1");
    const k1 = document.createElementNS(NS, "stop"); k1.setAttribute("offset", "0%"); k1.setAttribute("stop-color", "#ffffff");
    const k2 = document.createElementNS(NS, "stop"); k2.setAttribute("offset", "60%"); k2.setAttribute("stop-color", "#c084fc");
    const k3 = document.createElementNS(NS, "stop"); k3.setAttribute("offset", "100%"); k3.setAttribute("stop-color", "#7c3aed");
    stemGrad.append(k1, k2, k3);

    defs.append(shieldGrad, rimGrad, stemGrad);
    svg.appendChild(defs);

    // Hex shield
    const shield = document.createElementNS(NS, "path");
    shield.setAttribute("d", "M60 6 L106 28 L106 92 L60 114 L14 92 L14 28 Z");
    shield.setAttribute("fill", `url(#${uid}_s)`);
    shield.setAttribute("stroke", `url(#${uid}_r)`);
    shield.setAttribute("stroke-width", "3");
    svg.appendChild(shield);

    // Inner rim
    const innerRim = document.createElementNS(NS, "path");
    innerRim.setAttribute("d", "M60 14 L98 33 L98 87 L60 106 L22 87 L22 33 Z");
    innerRim.setAttribute("fill", "none");
    innerRim.setAttribute("stroke", "rgba(255,255,255,0.18)");
    innerRim.setAttribute("stroke-width", "1");
    svg.appendChild(innerRim);

    // Stem of K
    const stem = document.createElementNS(NS, "path");
    stem.setAttribute("d", "M36 30 L48 30 L48 90 L36 90 Z");
    stem.setAttribute("fill", `url(#${uid}_k)`);
    svg.appendChild(stem);

    // Upper wing
    const upWing = document.createElementNS(NS, "path");
    upWing.setAttribute("d", "M48 58 L75 30 L89 30 L59 61 Z");
    upWing.setAttribute("fill", "#c084fc");
    svg.appendChild(upWing);

    // Lower wing
    const lowWing = document.createElementNS(NS, "path");
    lowWing.setAttribute("d", "M54 54 L90 90 L75 90 L46 62 Z");
    lowWing.setAttribute("fill", "#818cf8");
    svg.appendChild(lowWing);

    // Cyan lightning bolt
    const bolt = document.createElementNS(NS, "path");
    bolt.setAttribute("d", "M60 34 L54 52 L62 50 L53 74 L69 48 L61 50 Z");
    bolt.setAttribute("fill", "#38bdf8");
    svg.appendChild(bolt);

    // Diamond highlight dot
    const dot = document.createElementNS(NS, "circle");
    dot.setAttribute("cx", "53");
    dot.setAttribute("cy", "60");
    dot.setAttribute("r", "2");
    dot.setAttribute("fill", "#ffffff");
    svg.appendChild(dot);

    return svg;
  };
  const CLIP_D = "M21 11.5l-8.6 8.6a5.5 5.5 0 0 1-7.8-7.8l8.6-8.6a3.7 3.7 0 0 1 5.2 5.2l-8.6 8.6a1.8 1.8 0 0 1-2.6-2.6l7.9-7.9";
  const setIconLabel = (el, icon, label) => {
    const span = document.createElement("span");
    span.textContent = label || "";
    el.replaceChildren(icon, span);
  };
  const FONT = '"Segoe UI","Helvetica Neue",Arial,sans-serif';

  // =====================================================================
  //  Futuristic Cyber-Luxe Dock & HUD (100% inline styles for strict CSP)
  // =====================================================================
  const DOCK_COLLAPSED = "translateX(calc(100% - 36px))";
  const dock = document.createElement("div");
  dock.id = "rg-dock";
  Object.assign(dock.style, {
    position: "fixed", right: "0", bottom: "110px", zIndex: "999999",
    display: "flex", alignItems: "stretch",
    fontFamily: FONT, userSelect: "none",
    transform: DOCK_COLLAPSED,
    transition: "transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease",
    opacity: "0.88",
  });

  const handle = document.createElement("div");
  handle.id = "rg-handle";
  Object.assign(handle.style, {
    width: "36px", minHeight: "94px",
    borderRadius: "14px 0 0 14px",
    background: "linear-gradient(135deg, rgba(20, 29, 52, 0.96), rgba(11, 17, 32, 0.98))",
    border: "1px solid rgba(201, 162, 75, 0.55)", borderRight: "0",
    boxShadow: "-4px 0 20px rgba(0, 0, 0, 0.45)",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "9px",
    cursor: "pointer", color: "#e8cc85",
    transition: "border-color 0.2s, box-shadow 0.2s",
  });
  const handleIcon = mkKyperLogo(20);
  handleIcon.style.filter = "drop-shadow(0 0 6px rgba(167, 139, 250, 0.6))";
  try {
    handleIcon.animate(
      [{ transform: "translateY(0px) rotate(0deg)" }, { transform: "translateY(-3px) rotate(-3deg)" }, { transform: "translateY(0px) rotate(0deg)" }],
      { duration: 2600, iterations: Infinity, easing: "ease-in-out" }
    );
  } catch {}

  const led = document.createElement("div");
  Object.assign(led.style, {
    width: "7px", height: "7px", borderRadius: "50%",
    background: "#c9a24b", boxShadow: "0 0 7px #c9a24b",
    transition: "background 0.3s, box-shadow 0.3s",
  });
  let ledAnim = null;
  const setLedActive = (on) => {
    led.style.background = on ? "#3fb68b" : "#c9a24b";
    led.style.boxShadow = on ? "0 0 10px #3fb68b" : "0 0 7px #c9a24b";
    if (on && !ledAnim) {
      try {
        ledAnim = led.animate(
          [{ opacity: 1, transform: "scale(1)" }, { opacity: 0.35, transform: "scale(0.8)" }, { opacity: 1, transform: "scale(1)" }],
          { duration: 1800, iterations: Infinity, easing: "ease-in-out" }
        );
      } catch {}
    } else if (!on && ledAnim) {
      try { ledAnim.cancel(); } catch {}
      ledAnim = null;
    }
  };
  handle.append(handleIcon, led);

  const panel = document.createElement("div");
  panel.id = "rg-panel";
  Object.assign(panel.style, {
    width: "260px", padding: "12px 14px",
    background: "rgba(14, 21, 38, 0.96)",
    backdropFilter: "blur(20px)", webkitBackdropFilter: "blur(20px)",
    border: "1px solid rgba(201, 162, 75, 0.42)", borderRight: "0",
    borderRadius: "0 0 0 16px",
    boxShadow: "-10px 10px 30px rgba(0, 0, 0, 0.6)",
    color: "#e8ebf2", display: "flex", flexDirection: "column", gap: "10px",
    boxSizing: "border-box",
  });

  const header = document.createElement("div");
  Object.assign(header.style, {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    paddingBottom: "6px", borderBottom: "1px solid rgba(255, 255, 255, 0.08)",
  });
  const brand = document.createElement("div");
  Object.assign(brand.style, {
    fontSize: "12px", fontWeight: "700", letterSpacing: "0.5px",
    color: "#e8cc85", display: "flex", alignItems: "center", gap: "6px",
  });
  const brandIcon = mkKyperLogo(17);
  try {
    brandIcon.animate(
      [{ transform: "translateY(0px)" }, { transform: "translateY(-2px)" }, { transform: "translateY(0px)" }],
      { duration: 2600, iterations: Infinity, easing: "ease-in-out" }
    );
  } catch {}
  brand.append(brandIcon, document.createTextNode("KYPER"));

  let isProUser = false;
  let freeRemaining = 15;
  let freeLimit = 15;
  let autoIsOn = false;
  const todayKeyUtc = () => { const d = new Date(); return `${d.getUTCFullYear()}-${d.getUTCMonth() + 1}-${d.getUTCDate()}`; };
  const readPlanFromStorage = (d) => {
    if (!d) return;
    isProUser = d.plan === "pro" && !!d.licenseKey && (!d.proExpiresAt || Date.now() <= d.proExpiresAt);
    const u = d.gtFreeUsage && d.gtFreeUsage.day === todayKeyUtc() ? Number(d.gtFreeUsage.used) || 0 : 0;
    freeRemaining = isProUser ? 9999 : Math.max(0, freeLimit - u);
  };

  const statusBadge = document.createElement("span");
  const paintBadge = (on) => {
    autoIsOn = !!on;
    if (isProUser) {
      statusBadge.textContent = on ? "👑 PRO · AUTO" : "👑 PRO";
      Object.assign(statusBadge.style, {
        fontSize: "9px", fontWeight: "700", textTransform: "uppercase", letterSpacing: "0.7px",
        padding: "2px 7px", borderRadius: "10px",
        background: on ? "rgba(63, 182, 139, 0.2)" : "rgba(201, 162, 75, 0.18)",
        color: on ? "#3fb68b" : "#f3d690",
        border: on ? "1px solid rgba(63, 182, 139, 0.45)" : "1px solid rgba(201, 162, 75, 0.45)",
      });
    } else {
      statusBadge.textContent = `FREE · ${freeRemaining}/${freeLimit}`;
      Object.assign(statusBadge.style, {
        fontSize: "9px", fontWeight: "700", textTransform: "uppercase", letterSpacing: "0.6px",
        padding: "2px 7px", borderRadius: "10px",
        background: freeRemaining <= 3 ? "rgba(239, 83, 80, 0.18)" : "rgba(255, 255, 255, 0.06)",
        color: freeRemaining <= 3 ? "#ef8380" : "#9aa6be",
        border: freeRemaining <= 3 ? "1px solid rgba(239, 83, 80, 0.45)" : "1px solid rgba(255, 255, 255, 0.12)",
      });
    }
  };
  paintBadge(false);
  header.append(brand, statusBadge);

  const btn = document.createElement("button");
  Object.assign(btn.style, {
    display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
    width: "100%", height: "38px", border: "none", borderRadius: "9px",
    cursor: "pointer", fontSize: "13px", fontWeight: "600", letterSpacing: "0.3px",
    fontFamily: FONT, color: "#0b1120",
    background: "linear-gradient(135deg, #e8cc85 0%, #c9a24b 100%)",
    boxShadow: "0 3px 12px rgba(201, 162, 75, 0.25)",
    transition: "transform 0.1s ease, filter 0.15s ease, box-shadow 0.15s ease",
  });
  btn.addEventListener("mouseenter", () => { btn.style.filter = "brightness(1.08)"; btn.style.boxShadow = "0 5px 16px rgba(201, 162, 75, 0.42)"; });
  btn.addEventListener("mouseleave", () => { btn.style.filter = ""; btn.style.boxShadow = "0 3px 12px rgba(201, 162, 75, 0.25)"; });
  const setBtn = (label) => setIconLabel(btn, mkKyperLogo(18, { onYellow: true }), label);
  setBtn("Suggest Reply (Alt+G)");

  const chipsRow = document.createElement("div");
  Object.assign(chipsRow.style, { display: "flex", flexWrap: "wrap", gap: "6px" });

  const paintChip = (el, active, locked) => {
    Object.assign(el.style, {
      display: "inline-flex", alignItems: "center", gap: "5px",
      padding: "5px 9px", fontSize: "11px", fontWeight: "600", borderRadius: "7px",
      background: active ? "rgba(63, 182, 139, 0.18)" : "rgba(255, 255, 255, 0.05)",
      color: locked ? "#76829b" : active ? "#3fb68b" : "#c4cada",
      border: active ? "1px solid #3fb68b" : "1px solid rgba(255, 255, 255, 0.14)",
      cursor: "pointer", transition: "all 0.15s ease", fontFamily: FONT,
      opacity: locked ? "0.75" : "1",
    });
  };

  // ---- Per-Chat Quick One-Click Mood Switcher inside Dock ----
  const isEmailSite = PLATFORM === "gmail" || PLATFORM === "outlook";
  const MOODS = isEmailSite
    ? [
        { label: "💼 Pro", val: "polite and professional", pro: false },
        { label: "😊 Chill", val: "warm, friendly and polite", pro: false },
        { label: "😤 Rude", val: "rude, blunt and curt", pro: true },
      ]
    : [
        { label: "💼 Pro", val: "polite and professional", pro: false },
        { label: "😊 Chill", val: "warm, friendly and polite", pro: false },
        { label: "❤️ Love", val: "deeply romantic, loving and caring (girlfriend or partner)", pro: false },
        { label: "😉 Flirty", val: "flirty, romantic and playful", pro: true },
        { label: "🔥 Spicy", val: "bold, spicy and intense flirting (18+ consenting adults, cheeky and teasing)", pro: true },
        { label: "😤 Rude", val: "rude, blunt and curt", pro: true },
        { label: "🤬 Gaali", val: "unfiltered desi roast, savage gaali and brutal comebacks", pro: true },
      ];
  let defaultTone = "polite and professional";
  let chatTones = {}; // "platform|chatId" -> tone
  let activeTone = defaultTone;
  let lastMoodChat = "";

  const activeChatInfo = () => {
    if (isEmailSite) return { key: "", label: "" };
    if (PLATFORM === "whatsapp") {
      const h = document.querySelector("#main header") || document.querySelector("header");
      const el = h && (h.querySelector("span[title]") || h.querySelector('span[dir="auto"]'));
      const n = el ? (el.getAttribute("title") || el.innerText || "").trim().slice(0, 60) : "";
      return n ? { key: "whatsapp|" + n.toLowerCase(), label: n } : { key: "", label: "" };
    }
    if (PLATFORM === "instagram") {
      const id = ((location.pathname.match(/\/direct\/t\/([^/?#]+)/) || [])[1]) || "";
      const h = document.querySelector('[role="main"] header, main header');
      const el = h && h.querySelector('h1, h2, span[dir="auto"], span');
      const lbl = el ? (el.innerText || "").trim().slice(0, 50) : id;
      return id ? { key: "instagram|" + id, label: lbl || "this chat" } : { key: "", label: "" };
    }
    if (PLATFORM === "facebook") {
      const id = ((location.pathname.match(/\/t\/([^/?#]+)/) || [])[1]) || "";
      return id ? { key: "facebook|" + id, label: "this chat" } : { key: "", label: "" };
    }
    if (PLATFORM === "snapchat") {
      const id = ((location.pathname.match(/\/web\/([^/?#]+)/) || [])[1]) || "";
      let lbl = "";
      const box = [...document.querySelectorAll('div[role="textbox"][contenteditable="true"], [contenteditable="true"], textarea')].pop();
      let p = box;
      for (let i = 0; i < 12 && p && p.parentElement && !lbl; i++) {
        p = p.parentElement;
        for (const h of p.querySelectorAll('h1, h2, h3, [role="heading"], header')) {
          if (box && box.contains(h)) continue;
          const r = h.getBoundingClientRect ? h.getBoundingClientRect() : { width: 0, height: 0 };
          if (r.width <= 0 || r.height <= 0) continue;
          const t = (h.innerText || "").split("\n")[0].trim();
          if (t && t.length < 60 && !/^(snapchat|chat|chats|friends|inbox|messages?|new chat|web)$/i.test(t)) { lbl = t; break; }
        }
      }
      const keyId = id || lbl.toLowerCase();
      return keyId ? { key: "snapchat|" + keyId, label: lbl || "this chat" } : { key: "", label: "" };
    }
    return { key: "", label: "" };
  };

  const moodGrid = document.createElement("div");
  Object.assign(moodGrid.style, {
    display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "5px",
  });
  const moodBtns = [];
  const paintMoods = () => {
    for (const { el, val, label, pro } of moodBtns) {
      const locked = pro && !isProUser;
      const on = !locked && val === activeTone;
      el.textContent = locked ? label + " 🔒" : label;
      Object.assign(el.style, {
        padding: "5px 3px", fontSize: "10px", fontWeight: "600", borderRadius: "7px",
        cursor: "pointer", fontFamily: FONT, textAlign: "center", whiteSpace: "nowrap",
        background: on ? "rgba(201, 162, 75, 0.24)" : "rgba(255, 255, 255, 0.04)",
        color: locked ? "#6d7891" : on ? "#f3d690" : "#9aa6be",
        border: on ? "1px solid #e8cc85" : "1px solid rgba(255, 255, 255, 0.1)",
        boxShadow: on ? "0 0 10px rgba(201, 162, 75, 0.25)" : "none",
        transition: "all 0.15s ease",
        opacity: locked ? "0.75" : "1",
      });
    }
  };
  const syncChatMood = () => {
    const info = activeChatInfo();
    let target = (isProUser && info.key && chatTones[info.key]) ? chatTones[info.key] : defaultTone;
    if (!isProUser && /flirt|spicy|18\+|rude/i.test(target)) target = "warm, friendly and polite";
    if (info.key !== lastMoodChat || target !== activeTone) {
      lastMoodChat = info.key;
      activeTone = target;
      paintMoods();
    }
  };
  for (const m of MOODS) {
    const mb = document.createElement("button");
    mb.textContent = m.label;
    mb.title = m.pro ? m.label + " (PRO feature)" : "Switch mood to " + m.label;
    mb.addEventListener("click", () => {
      if (m.pro && !isProUser) {
        return toast(`👑 ${m.label} is a PRO feature! Click the KYPER icon in Chrome toolbar → Plan tab to unlock Pro.`, true);
      }
      const info = activeChatInfo();
      activeTone = m.val;
      paintMoods();
      if (isProUser && info.key) {
        chatTones[info.key] = m.val;
        const keys = Object.keys(chatTones);
        if (keys.length > 100) delete chatTones[keys[0]];
        try { chrome.storage.local.set({ chatTones }); } catch {}
      } else {
        defaultTone = m.val;
        try { chrome.storage.local.set({ tone: m.val }); } catch {}
      }
    });
    moodBtns.push({ el: mb, val: m.val, label: m.label, pro: m.pro });
    moodGrid.appendChild(mb);
  }
  paintMoods();
  let onPlanRefresh = () => {};
  const refreshAllPlanUI = () => {
    paintBadge(autoIsOn);
    paintMoods();
    syncChatMood();
    onPlanRefresh();
  };
  try {
    chrome.storage.local.get(["tone", "chatTones", "plan", "licenseKey", "proExpiresAt", "gtFreeUsage"], (d) => {
      readPlanFromStorage(d);
      if (d && d.tone) defaultTone = d.tone;
      if (d && d.chatTones && typeof d.chatTones === "object") chatTones = d.chatTones;
      refreshAllPlanUI();
    });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== "local") return;
      if (ch.tone && ch.tone.newValue) defaultTone = ch.tone.newValue;
      if (ch.chatTones && ch.chatTones.newValue) chatTones = ch.chatTones.newValue;
      if (ch.plan || ch.licenseKey || ch.proExpiresAt || ch.gtFreeUsage) {
        chrome.storage.local.get(["plan", "licenseKey", "proExpiresAt", "gtFreeUsage"], (d) => {
          readPlanFromStorage(d);
          refreshAllPlanUI();
        });
      } else {
        syncChatMood();
      }
    });
  } catch {}
  if (!isEmailSite) setInterval(syncChatMood, 600);

  const attachBtn = document.createElement("button");
  paintChip(attachBtn, false);

  chipsRow.append(attachBtn);
  panel.append(header, btn, moodGrid, chipsRow);
  dock.append(handle, panel);
  document.body.appendChild(dock);

  let hovering = false, busy = false, hideTimer;
  const showBtn = () => {
    clearTimeout(hideTimer);
    dock.style.transform = "translateX(0)";
    dock.style.opacity = "1";
  };
  const hideBtn = () => {
    if (hovering || busy) return;
    dock.style.transform = DOCK_COLLAPSED;
    dock.style.opacity = "0.88";
  };
  const idle = () => {
    busy = false;
    btn.disabled = false;
    btn.style.opacity = "1";
    setBtn("Suggest Reply (Alt+G)");
    hideTimer = setTimeout(hideBtn, 1500);
  };
  dock.addEventListener("mouseenter", () => { hovering = true; showBtn(); });
  dock.addEventListener("mouseleave", () => { hovering = false; hideTimer = setTimeout(hideBtn, 300); });
  handle.addEventListener("click", () => {
    if (dock.style.transform === "translateX(0px)" || dock.style.transform === "translateX(0)") { hovering = false; hideBtn(); }
    else showBtn();
  });

  // Subtle top-right toast pill (never blocks chat messages, always auto-dismisses)
  const toastEl = document.createElement("div");
  Object.assign(toastEl.style, {
    position: "fixed", top: "14px", right: "14px", zIndex: "999999", maxWidth: "270px",
    padding: "8px 12px", borderRadius: "10px",
    background: "rgba(11, 17, 32, 0.94)",
    backdropFilter: "blur(12px)", webkitBackdropFilter: "blur(12px)",
    color: "#e8ebf2", border: "1px solid rgba(255, 255, 255, 0.1)",
    borderLeft: "3px solid #c9a24b",
    boxShadow: "0 6px 20px rgba(0, 0, 0, 0.45)",
    fontSize: "11.5px", lineHeight: "1.4", display: "none", fontFamily: FONT,
    userSelect: "text", webkitUserSelect: "text", cursor: "pointer",
  });
  const toastText = document.createElement("div");
  Object.assign(toastText.style, { userSelect: "text", webkitUserSelect: "text", wordBreak: "break-word" });
  const toastBar = document.createElement("div");
  Object.assign(toastBar.style, { display: "none", gap: "8px", marginTop: "6px", justifyContent: "flex-end" });

  const mkBtn = (label) => {
    const b = document.createElement("button");
    b.textContent = label;
    Object.assign(b.style, {
      padding: "2px 8px", fontSize: "10.5px", fontWeight: "600", cursor: "pointer", fontFamily: FONT,
      background: "transparent", color: "#e8cc85", border: "1px solid #c9a24b", borderRadius: "5px",
    });
    return b;
  };
  const copyBtn = mkBtn("Copy");
  const closeBtn = mkBtn("Close");
  toastBar.append(copyBtn, closeBtn);
  toastEl.append(toastText, toastBar);
  document.body.appendChild(toastEl);

  copyBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    const t = toastText.textContent;
    try {
      await navigator.clipboard.writeText(t);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    copyBtn.textContent = "Copied";
    setTimeout(() => (copyBtn.textContent = "Copy"), 1500);
  });
  closeBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    clearTimeout(toastTimer);
    toastEl.style.display = "none";
  });
  toastEl.addEventListener("click", () => {
    clearTimeout(toastTimer);
    toastEl.style.display = "none";
  });

  let toastTimer;
  function toast(text, isError, showActions = false) {
    toastText.textContent = text;
    toastEl.style.borderLeftColor = isError ? "#d9534f" : "#c9a24b";
    toastBar.style.display = showActions ? "flex" : "none";
    toastEl.style.display = "block";
    clearTimeout(toastTimer);
    if (!showActions) {
      toastTimer = setTimeout(() => (toastEl.style.display = "none"), isError ? 3400 : 2200);
    }
  }

  // =====================================================================
  //  Optional PDF attachment (works on every site)
  // =====================================================================
  let pdfAttach = null; // { name, data(base64) }
  const MAX_PDF = 10 * 1024 * 1024;
  const shortName = (n) => (n.length > 16 ? n.slice(0, 13) + "..." : n);
  const setAttach = () => {
    const locked = !isProUser;
    setIconLabel(attachBtn, mkIcon(CLIP_D, true), locked ? "PDF 🔒" : pdfAttach ? "PDF: " + shortName(pdfAttach.name) + " ✕" : "Attach PDF");
    paintChip(attachBtn, !locked && !!pdfAttach, locked);
    attachBtn.title = locked ? "PDF Reader (PRO feature)" : pdfAttach ? "Click to remove " + pdfAttach.name : "Attach a PDF so the reply can use it";
  };
  setAttach();
  onPlanRefresh = () => setAttach();

  const fileInput = document.createElement("input");
  fileInput.type = "file";
  fileInput.accept = "application/pdf,.pdf";
  fileInput.style.display = "none";
  document.body.appendChild(fileInput);
  fileInput.addEventListener("change", () => {
    const f = fileInput.files && fileInput.files[0];
    fileInput.value = "";
    if (!f) return;
    if (!/pdf$/i.test(f.type) && !/\.pdf$/i.test(f.name)) return toast("Please choose a PDF file.", true);
    if (f.size > MAX_PDF) return toast("This PDF is too large (max 10 MB).", true);
    const rd = new FileReader();
    rd.onload = () => {
      pdfAttach = { name: f.name, data: String(rd.result).split(",")[1] };
      setAttach();
      toast("PDF attached: " + f.name + ". Now click Suggest Reply.");
    };
    rd.onerror = () => toast("Could not read that file.", true);
    rd.readAsDataURL(f);
  });
  attachBtn.addEventListener("click", () => {
    if (!isProUser) return toast("👑 PDF Knowledge Reader is a PRO feature! Open KYPER popup → Plan tab to unlock Pro.", true);
    if (pdfAttach) { pdfAttach = null; setAttach(); toast("PDF removed."); }
    else fileInput.click();
  });

  // =====================================================================
  //  Shared helpers
  // =====================================================================
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const tidy = (t) => (t || "").replace(/[\u200e\u200f]/g, "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

  // innerText does not work on detached clones, so add line breaks by hand.
  function plainText(node) {
    const c = node.cloneNode(true);
    c.querySelectorAll("br").forEach((b) => b.replaceWith("\n"));
    c.querySelectorAll("div,p,li,tr").forEach((d) => d.append("\n"));
    return tidy(c.textContent);
  }

  function caretToStart(box) {
    const sel = window.getSelection();
    const r = document.createRange();
    r.setStart(box, 0);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
  }

  // Put text in a contenteditable box. For emails we keep the quoted original below the reply.
  async function insertText(box, text, quoteSel) {
    box.focus();
    if (box.tagName === "TEXTAREA" || box.tagName === "INPUT") {
      const proto = box.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(box, text.replace(/\n/g, " "));
      box.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    const q = quoteSel ? box.querySelector(quoteSel) : null;
    if (q) {
      let top = q;
      while (top.parentElement && top.parentElement !== box) top = top.parentElement;
      while (box.firstChild && box.firstChild !== top) box.removeChild(box.firstChild);
      caretToStart(box);
    } else {
      document.execCommand("selectAll", false, null);
      document.execCommand("delete", false, null);
    }
    const lines = text.split("\n");
    lines.forEach((ln, i) => {
      if (ln) document.execCommand("insertText", false, ln);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, null);
    });
    // Some editors (Instagram / Facebook) ignore execCommand. Fall back to a paste event.
    // Editors update their DOM a moment late, so wait before deciding. Pasting on top of text that
    // was already inserted is what made one reply appear 2-3 times, so WhatsApp / Gmail / Outlook never use it.
    if (PLATFORM === "instagram" || PLATFORM === "facebook" || PLATFORM === "snapchat") {
      const probe = text.replace(/\s+/g, " ").slice(0, 12);
      const has = () => (box.innerText || "").replace(/\s+/g, " ").includes(probe);
      let ok = false;
      for (let i = 0; i < 5 && !ok; i++) { await sleep(60); ok = has(); }
      if (!ok) {
        try {
          const dt = new DataTransfer();
          dt.setData("text/plain", text);
          box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
        } catch {}
      }
    }
    return true;
  }

  async function waitFor(fn, tries = 20, gap = 150) {
    for (let i = 0; i < tries; i++) {
      const v = fn();
      if (v) return v;
      await sleep(gap);
    }
    return null;
  }

  // =====================================================================
  //  WhatsApp Web
  // =====================================================================
  const whatsapp = {
    read() {
      const root = document.querySelector("#main") || document;
      let nodes = [...root.querySelectorAll(".message-in, .message-out")].slice(-30);
      if (!nodes.length) nodes = [...root.querySelectorAll("div[data-pre-plain-text]")].slice(-30);
      const out = [];
      for (const n of nodes) {
        const quotedEl = n.querySelector('[data-testid*="quoted"], [aria-label*="Quoted"], .quoted-mention');
        let quote = "";
        if (quotedEl) {
          const qt = (quotedEl.innerText || "").replace(/\s+/g, " ").trim();
          // Skip sender label on first line if multi-line quote
          const qlines = (quotedEl.innerText || "").split("\n").map((s) => s.trim()).filter(Boolean);
          quote = (qlines.length > 1 ? qlines.slice(1).join(" ") : qt).slice(0, 90);
        }

        const QUOTE_SEL = '[data-testid*="quoted"], [aria-label*="Quoted"], .quoted-mention';
        const inQuote = (el) => !!(el && el.closest && el.closest(QUOTE_SEL));
        const textHost = n.querySelector("div[data-pre-plain-text]") || n;
        const rawSpans = [...textHost.querySelectorAll("span.selectable-text")].filter((s) => !inQuote(s));
        const topSpans = rawSpans.filter((s) => !(s.parentElement && s.parentElement.closest && s.parentElement.closest("span.selectable-text")));
        let text = topSpans.length
          ? topSpans.map((s) => (s.innerText || "").trim()).filter(Boolean).join("\n")
          : "";
        if (!text && textHost !== n) text = (textHost.innerText || "").trim();

        // Detect media tags ONLY outside quoted reply previews
        const hasMedia = (sel) => [...n.querySelectorAll(sel)].some((el) => !inQuote(el));
        let media = "";
        if (hasMedia('[data-icon*="ptt"], [data-icon*="audio"], [aria-label*="Voice message" i], audio')) media = "[Voice note]";
        else if (hasMedia('[data-testid*="sticker"], [aria-label*="Sticker" i]')) media = "[Sticker]";
        else if (hasMedia('[data-icon*="video"], [data-icon*="media-play"], video')) media = "[Video]";
        else if (hasMedia('[data-icon*="document"], [data-testid*="document"]')) media = "[Document]";
        else if ([...n.querySelectorAll('img[src^="blob:"], [aria-label*="Open picture" i]')].some((im) => {
          if (inQuote(im)) return false;
          const r = im.getBoundingClientRect ? im.getBoundingClientRect() : { width: 100 };
          return r.width >= 50 || im.tagName !== "IMG";
        })) media = "[Photo]";

        if (!text && !media) continue;
        const body = [media, text].filter(Boolean).join(" ").trim();
        const full = quote ? `(replying to "${quote}") ${body}` : body;

        const row = n.closest(".message-in, .message-out, [data-id]") || n;
        const idRow = n.closest("[data-id]");
        const idVal = (idRow && idRow.getAttribute("data-id")) || (row.getAttribute && row.getAttribute("data-id")) || "";
        const mine = n.classList.contains("message-out") || !!n.closest(".message-out") || (!n.classList.contains("message-in") && !n.closest(".message-in") && idVal.startsWith("true_"));
        out.push({ from: mine ? "Me" : "Them", text: full });
      }
      return { kind: "chat", messages: out };
    },
    async fill(text) {
      const box = document.querySelector('footer div[contenteditable="true"]');
      return box ? insertText(box, text) : false;
    },
  };

  // =====================================================================
  //  Gmail
  // =====================================================================
  const GMAIL_BOX = 'div[aria-label="Message Body"][contenteditable="true"], div.editable[role="textbox"][contenteditable="true"], div[role="textbox"][g_editable="true"]';
  const gmail = {
    read() {
      const subject = (document.querySelector("h2.hP") || {}).innerText || "";
      const accLabel = (document.querySelector('a[aria-label*="Google Account"]') || {}).ariaLabel || "";
      const m = accLabel.match(/\(([^)]+@[^)]+)\)/);
      const acct = m ? m[1].toLowerCase() : "";
      const out = [];
      let sender = "";
      for (const it of [...document.querySelectorAll("div.adn")].slice(-5)) {
        const body = it.querySelector("div.a3s");
        if (!body) continue;
        const c = body.cloneNode(true);
        c.querySelectorAll(".gmail_quote, .gmail_signature, blockquote, .yj6qo, .adL").forEach((n) => n.remove());
        const text = plainText(c);
        if (!text) continue;
        const g = it.querySelector("span.gD");
        const name = g ? g.getAttribute("name") || g.innerText : "";
        const email = g ? (g.getAttribute("email") || "").toLowerCase() : "";
        const mine = (g && /^me$/i.test((g.innerText || "").trim())) || (acct && email && email === acct);
        out.push({ from: mine ? "Me" : "Them", text });
        if (!mine && name) sender = name;
      }
      return { kind: "email", subject: tidy(subject), sender, messages: out };
    },
    async fill(text) {
      const find = () => [...document.querySelectorAll(GMAIL_BOX)].filter(visible).pop();
      let box = find();
      if (!box) {
        const rb = [...document.querySelectorAll('span.ams.bkH, [data-tooltip="Reply"]')].filter(visible)[0];
        if (rb) { rb.click(); box = await waitFor(find); }
      }
      return box ? insertText(box, text, ".gmail_quote, .gmail_extra, blockquote") : false;
    },
  };

  // =====================================================================
  //  Outlook (outlook.live.com / office.com / office365.com)
  // =====================================================================
  const OUT_BOX = 'div[role="textbox"][contenteditable="true"]';
  const outlook = {
    read() {
      const pane = document.querySelector('#ReadingPaneContainerId, [data-app-section="ConversationContainer"], div[role="main"]') || document;
      const subject = (pane.querySelector('[role="heading"]') || {}).innerText || "";
      let bodies = [...pane.querySelectorAll('div[aria-label="Message body"], div[id^="UniqueMessageBody"]')].filter((b) => !b.isContentEditable);
      if (!bodies.length) bodies = [...pane.querySelectorAll('[role="document"]')].filter((b) => !b.isContentEditable);
      const out = [];
      for (const b of bodies.slice(-4)) {
        const c = b.cloneNode(true);
        c.querySelectorAll('blockquote, #divRplyFwdMsg, div[id$="divRplyFwdMsg"]').forEach((n) => n.remove());
        const text = plainText(c);
        if (text) out.push({ from: "Them", text });
      }
      return { kind: "email", subject: tidy(subject), sender: "", messages: out };
    },
    async fill(text) {
      const find = () => {
        const all = [...document.querySelectorAll(OUT_BOX)].filter(visible);
        return all.find((b) => /message body/i.test(b.getAttribute("aria-label") || "")) || all.pop();
      };
      let box = find();
      if (!box) {
        const rb = [...document.querySelectorAll('button[aria-label="Reply"], button[title="Reply"], [id*="ReplyButton"]')].filter(visible)[0];
        if (rb) { rb.click(); box = await waitFor(find); }
      }
      return box ? insertText(box, text, '#divRplyFwdMsg, div[id$="divRplyFwdMsg"], blockquote') : false;
    },
  };

  // =====================================================================
  //  Instagram DMs + Facebook / Messenger
  //  These sites use scrambled class names, so we find the message box,
  //  then read the text bubbles above it. A bubble on the right = Me, left = Them.
  // =====================================================================
  const NOISE = /^(seen|seen by .*|delivered|sent|active (now|.* ago)|today|yesterday|(mon|tue|wed|thu|fri|sat|sun)[a-z]*|\d{1,2}:\d{2}(\s?[ap]m)?|message\.{0,3}|aa|type a message\.{0,3}|enter|send|reply|forwarded|edited|unsent|you sent|you replied to .*|replied to you)$/i;
  const TEXT_SEL = PLATFORM === "snapchat" ? "span, p, div" : 'div[dir="auto"], span[dir="auto"]';

  function findComposer() {
    if (PLATFORM === "snapchat") {
      const sc = [...document.querySelectorAll('div[role="textbox"][contenteditable="true"], [contenteditable="true"], textarea')].filter(visible);
      return sc.find((b) => b.contains(document.activeElement)) || sc[sc.length - 1] || null;
    }
    const all = [...document.querySelectorAll('div[role="textbox"][contenteditable="true"]')].filter(visible);
    const labelled = all.filter((b) => /message/i.test((b.getAttribute("aria-label") || "") + (b.getAttribute("aria-placeholder") || "")));
    const pool = labelled.length ? labelled : PLATFORM === "instagram" ? all : [];
    return pool.find((b) => b.contains(document.activeElement)) || pool[pool.length - 1] || null;
  }

  const social = {
    read() {
      return { kind: "chat", messages: this.list(28) };
    },
    list(limit) {
      const box = findComposer();
      if (!box) return [];
      const br = box.getBoundingClientRect();
      const left = br.left - 160, right = br.right + 160;
      const mid = (br.left + br.right) / 2;

      const collect = (root) => {
        const rootTop = root.getBoundingClientRect().top;
        const tall = root.getBoundingClientRect().height > 400;
        return [...root.querySelectorAll(TEXT_SEL)].filter((el) => {
          if (box.contains(el) || el.closest('[role="textbox"], header, [role="banner"], [role="navigation"]')) return false;
          if (PLATFORM === "snapchat" && el.closest('button, [role="button"], a, [contenteditable="true"]')) return false;
          if (el.querySelector(TEXT_SEL) || !visible(el)) return false;
          const t = (el.innerText || "").trim();
          if (!t || t.length > 2000 || NOISE.test(t)) return false;
          const r = el.getBoundingClientRect();
          if (r.left < left || r.right > right || r.bottom > br.top + 5) return false;
          if (tall && r.top < rootTop + 70) return false;
          return true;
        });
      };

      let pane = box, items = [];
      for (let i = 0; i < 14 && pane.parentElement; i++) {
        pane = pane.parentElement;
        items = collect(pane);
        if (items.length >= 3) break;
      }
      items.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);

      const out = [];
      for (const el of (limit ? items.slice(-limit) : items)) {
        const r = el.getBoundingClientRect();
        const text = (el.innerText || "").trim();
        const from = (r.left + r.right) / 2 > mid ? "Me" : "Them";
        const last = out[out.length - 1];
        if (last && last.from === from && last.text === text) continue;
        out.push({ from, text });
      }
      return out;
    },
    async fill(text) {
      const box = findComposer();
      return box ? insertText(box, text) : false;
    },
  };

  // Saved contact name at the top of the open WhatsApp chat (used to detect papa / mummy / uncle etc.)
  const waContact = () => {
    const h = document.querySelector("#main header") || document.querySelector("header");
    const el = h && (h.querySelector("span[title]") || h.querySelector('span[dir="auto"]'));
    return el ? (el.getAttribute("title") || el.innerText || "").trim().slice(0, 80) : "";
  };

  const ADAPTERS = { whatsapp, gmail, outlook, instagram: social, facebook: social, snapchat: social };
  const SITE = ADAPTERS[PLATFORM];

  const EMPTY_MSG = {
    whatsapp: "No messages found. Please open a chat first.",
    gmail: "No email found. Open an email conversation first.",
    outlook: "No email found. Open an email in the reading pane first.",
    instagram: "No messages found. Open a chat (Direct) first.",
    facebook: "No messages found. Open a Messenger chat first.",
    snapchat: "No messages found. Open a chat on Snapchat Web first.",
  };

  let lastInsertedReply = "";
  const normCmp = (s) => String(s || "").replace(/\s+/g, " ").trim().toLowerCase();

  btn.addEventListener("click", () => {
    syncChatMood();
    let data;
    try { data = SITE.read(); } catch (e) { return toast("Could not read this page: " + e.message, true); }
    const messages = data.messages || [];
    // Empty chat with a message box open = write a first message (the toast says so). Not for email.
    const chatBox = () => (PLATFORM === "whatsapp" ? document.querySelector('footer div[contenteditable="true"]') : findComposer());
    const box = data.kind === "chat" ? chatBox() : null;
    const isOpener = !messages.length && data.kind === "chat" && !!box;
    if (!messages.length && !isOpener) return toast(EMPTY_MSG[PLATFORM], true);

    // Quick Hint / Draft-to-Reply: if user typed a short draft/hint in the chat box (not our own last reply), use it!
    let hint = "";
    if (box) {
      const rawDraft = String(typeof box.value === "string" ? box.value : box.innerText || "").trim();
      const isPlaceholder = /^(message|send a chat|type a message|aa)?\.{0,3}$/i.test(rawDraft);
      if (rawDraft && !isPlaceholder && rawDraft.length <= 200 && normCmp(rawDraft) !== normCmp(lastInsertedReply)) {
        hint = rawDraft;
      }
    }

    busy = true;
    showBtn();
    btn.disabled = true;
    setBtn(hint ? "Crafting hint..." : "Generating...");
    let done = false;
    const guard = setTimeout(() => {
      if (done) return;
      done = true;
      idle();
      toast("No response from the extension. Reload the extension and refresh this page.", true);
    }, 120000);
    try {
      chrome.runtime.sendMessage(
        { action: "suggest", messages, kind: data.kind, subject: data.subject || "", sender: data.sender || "", platform: PLATFORM, pdf: pdfAttach, contact: PLATFORM === "whatsapp" ? waContact() : "", tone: activeTone, hint },
        async (resp) => {
          if (done) return;
          done = true;
          clearTimeout(guard);
          idle();
          if (chrome.runtime.lastError) return toast("Extension error. Please refresh the page and try again.", true);
          if (!resp || resp.error) return toast((resp && resp.error) || "No reply was generated.", true);
          if (resp.plan === "pro") {
            isProUser = true;
            freeRemaining = 9999;
            refreshAllPlanUI();
          } else if (typeof resp.remaining === "number" && resp.plan === "free") {
            if (resp.limit) freeLimit = resp.limit;
            freeRemaining = Math.max(0, Math.min(freeLimit, resp.remaining));
            paintBadge(autoIsOn);
          }
          let ok = false;
          try { ok = await SITE.fill(resp.reply); } catch (e) { ok = false; }
          if (ok) {
            lastInsertedReply = resp.reply;
            setBtn("✓ Inserted");
            setTimeout(() => { if (!busy) setBtn("Suggest Reply (Alt+G)"); }, 1200);
          } else toast("Reply box not found:\n" + resp.reply, true, true);
        }
      );
    } catch (err) {
      done = true;
      clearTimeout(guard);
      idle();
      toast("Extension was reloaded. Please refresh this tab (F5) and try again.", true);
    }
  });

  // ---- Instant Keyboard Shortcut: Alt + G ----
  document.addEventListener("keydown", (e) => {
    if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && (e.code === "KeyG" || String(e.key || "").toLowerCase() === "g")) {
      e.preventDefault();
      e.stopPropagation();
      if (!busy) btn.click();
    }
  }, true);

  // =====================================================================
  //  Auto-reply (WhatsApp Web + Instagram DMs). OFF by default, you control it with a toggle.
  //  Turn it ON and it reads new messages and sends the reply by itself.
  //  Safety: never groups, random delay, hourly + daily caps, stop-words,
  //  replies to every message, pauses a chat when you type in it yourself.
  // =====================================================================
  if (PLATFORM === "whatsapp" || PLATFORM === "instagram" || PLATFORM === "snapchat") {
    const IG = PLATFORM !== "whatsapp"; // "IG" = the shared social adapter (Instagram + Snapchat)
    // Instagram and Snapchat each keep their OWN on/off switch and chat list, so WhatsApp auto-reply never turns them on by accident.
    const K = (n) => (IG ? (PLATFORM === "snapchat" ? "sn_" : "ig_") + n : n);
    const CFG_KEYS = [K("autoOn"), "autoScope", K("autoChats"), "autoMin", "autoMax", "autoPerHour", "autoDayCap"];
    const A = { on: false, scope: "chats", chats: [], min: 1, max: 3, perHour: 30, dayCap: 300 };
    let log = { day: "", count: 0, chats: {} };
    let ready = false, pending = false, lastShown = null, lastWhy = "";
    const handled = {};            // chat -> id of the last message we have dealt with
    const sentLog = {};            // chat -> [{ t: normalized text, at: time }] replies we sent ourselves
    const seen = { chat: "", id: "", at: 0 }; // when the newest message appeared (to wait for bursts)
    const QUIET = 900;             // ms of silence before we answer, so 3 quick messages get ONE reply
    const norm = (s) => String(s || "").replace(/\s+/g, " ").trim();
    const sentByUs = (chat, text) => {
      const t = norm(text);
      const list = (sentLog[chat] || []).filter((x) => Date.now() - x.at < 15 * 60 * 1000);
      sentLog[chat] = list;
      return !!t && list.some((x) => x.t === t);
    };
    const cand = { chat: "", id: "" };
    const paused = {};             // chat -> timestamp until which auto-reply is paused

    const dbg = (...a) => console.log("[KYPER]", ...a);
    const why = (r) => { if (r !== lastWhy) { lastWhy = r; dbg(r); } };
    const num = (v, d, lo, hi) => { v = Number(v); return Number.isFinite(v) && v > 0 ? Math.min(hi, Math.max(lo, v)) : d; };
    const dayKey = () => { const d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); };

    // ---- reading the page (uses the same message nodes as the Suggest Reply button) ----
    const msgRoot = () => document.querySelector("#main") || document;
    const GENERIC = /^(snapchat|chat|chats|friends|inbox|messages?|new chat|web)$/i;
    const snLabel = () => {
      const box = composer();
      let p = box;
      for (let i = 0; i < 12 && p && p.parentElement; i++) {
        p = p.parentElement;
        for (const h of p.querySelectorAll('h1, h2, h3, [role="heading"], header')) {
          if (box.contains(h) || !visible(h)) continue;
          const t = (h.innerText || "").split("\n")[0].trim();
          if (t && t.length < 60 && !GENERIC.test(t)) return t;
        }
      }
      return "";
    };
    const igLabel = () => {
      if (PLATFORM === "snapchat") return snLabel();
      const h = document.querySelector('[role="main"] header, main header');
      const el = h && h.querySelector('h1, h2, span[dir="auto"], span');
      return el ? (el.innerText || "").trim() : "";
    };
    // Instagram: the thread id in the address. Snapchat Web: an id in the address if there is one, else the friend's name at the top of the open chat.
    const igKey = () => {
      if (PLATFORM === "instagram") return ((location.pathname.match(/\/direct\/t\/([^/?#]+)/) || [])[1]) || "";
      const id = (location.pathname.match(/\/web\/([^/?#]+)/) || [])[1] || "";
      return id || snLabel();
    };
    const igSeen = {};            // chat -> { base, n }: how many identical messages we have counted (never goes down)
    const lastMsgIG = () => {
      const list = social.list(0);
      if (!list.length) return null;
      const chat = chatNameFast();
      const m = list[list.length - 1];
      const base = m.from + "|" + m.text.slice(0, 120);
      let n = list.filter((x) => x.from === m.from && x.text === m.text).length;
      const prev = igSeen[chat];
      if (prev && prev.base === base && prev.n > n) n = prev.n; // Instagram unloads old bubbles; do not mistake that for a new message
      igSeen[chat] = { base, n };
      return { id: base + "|" + n, mine: m.from === "Me" || sentByUs(chat, m.text), text: m.text, jid: "", group: false };
    };
    const lastMsg = () => {
      if (IG) return lastMsgIG();
      const nodes = msgRoot().querySelectorAll("div[data-pre-plain-text]");
      if (!nodes.length) return null;
      const n = nodes[nodes.length - 1];
      const row = n.closest("[data-id]");
      const rid = row ? row.getAttribute("data-id") || "" : "";
      const spans = [...n.querySelectorAll("span.selectable-text")].filter(
        (s) => !s.closest('[data-testid*="quoted"], [aria-label*="Quoted"], .quoted-mention')
      );
      const t = spans.length ? spans[spans.length - 1] : null;
      const text = ((t ? t.innerText : n.innerText) || "").trim();
      const mine = !!n.closest(".message-out") || rid.startsWith("true_");
      const id = rid || "t|" + (n.getAttribute("data-pre-plain-text") || "") + text.slice(0, 80);
      const jid = ((rid.match(/^(?:true|false)_([^_]+)_/) || [])[1]) || "";
      return { id, mine: mine || (!!text && sentByUs(chatNameFast(), text)), text, jid, group: rid.includes("@g.us") };
    };
    const chatName = () => {
      if (IG) return igKey();
      const h = document.querySelector("#main header") || document.querySelector("header");
      const el = h && (h.querySelector("span[title]") || h.querySelector('span[dir="auto"]'));
      const name = el ? (el.getAttribute("title") || el.innerText || "").trim() : "";
      if (name) return name;
      const m = lastMsg();
      return (m && m.jid) || "this-chat";
    };
    const chatNameFast = () => {
      if (IG) return igKey();
      const h = document.querySelector("#main header") || document.querySelector("header");
      const el = h && (h.querySelector("span[title]") || h.querySelector('span[dir="auto"]'));
      return el ? (el.getAttribute("title") || el.innerText || "").trim() : "";
    };
    const lbl = (c) => (IG ? igLabel() || "this chat" : c);
    const composer = () => (IG ? findComposer() : document.querySelector('footer div[contenteditable="true"]'));
    // Instagram may show a placeholder like "Message..." inside the box; that is not a draft.
    const boxText = () => {
      const b = composer() || {};
      const t = String(typeof b.value === "string" ? b.value : b.innerText || "").trim();
      return IG && /^(message|send a chat|aa)?\.{0,3}$/i.test(t) ? "" : t;
    };
    const capsBlock = (chat) => {
      if (log.day !== dayKey()) log = { day: dayKey(), count: 0, chats: {} };
      if (log.count >= A.dayCap) return "daily limit (" + A.dayCap + ")";
      const hr = (log.chats[chat] || []).filter((t) => Date.now() - t < 3600000);
      if (hr.length >= A.perHour) return "hourly limit for this chat (" + A.perHour + ")";
      return "";
    };
    const recordSent = (chat, text) => {
      if (text) (sentLog[chat] = sentLog[chat] || []).push({ t: norm(text), at: Date.now() });
      if (log.day !== dayKey()) log = { day: dayKey(), count: 0, chats: {} };
      log.count++;
      log.chats[chat] = (log.chats[chat] || []).filter((t) => Date.now() - t < 3600000).concat(Date.now());
      try { chrome.storage.local.set({ [K("autoLog")]: log }); } catch {}
    };

    // ---- sending (multilingual & adaptive) ----
    const SEND_WORDS = /^(send|enviar|envoyer|senden|inviare|invia|भेजें|भेजो|kirim|ارسال|отправить|보내기|送信)$/i;
    const SEND_SEL = [
      'footer button[aria-label="Send"]', 'footer [aria-label="Send"]', 'footer [data-testid="send"]',
      'footer [data-icon="send"]', 'footer [data-icon*="send"]', 'footer button[aria-label*="end" i]',
      'footer [data-testid="compose-btn-send"]', 'footer span[data-icon="send"]', 'footer span[data-icon="wds-ic-send"]'
    ].join(", ");

    const findSendWA = () => {
      const ic = document.querySelector(SEND_SEL);
      if (ic) return ic.closest("button") || ic.closest('[role="button"]') || ic;
      const footer = document.querySelector("footer") || document.querySelector("#main footer");
      if (footer) {
        for (const b of footer.querySelectorAll('button, [role="button"]')) {
          const lbl = (b.getAttribute("aria-label") || b.getAttribute("title") || "").trim();
          if (SEND_WORDS.test(lbl)) return b;
          if (b.querySelector('[data-icon*="send"], svg path[d*="M1.101"], svg path[d*="21.757"]')) return b;
        }
      }
      return null;
    };

    const findSendIG = () => {
      const box = composer();
      if (!box) return null;
      let p = box;
      for (let i = 0; i < 8 && p.parentElement; i++) {
        p = p.parentElement;
        const c = [...p.querySelectorAll('[aria-label="Send" i], div[role="button"], button')].find(
          (e) => visible(e) && !box.contains(e) && (/^send$/i.test((e.innerText || "").trim()) || /^send$/i.test(e.getAttribute("aria-label") || "") || SEND_WORDS.test((e.getAttribute("aria-label") || "").trim()))
        );
        if (c) return c.closest('[role="button"], button') || c;
      }
      return null;
    };

    const findSend = () => {
      if (IG) return findSendIG();
      return findSendWA();
    };

    async function sendNow() {
      const b = await waitFor(findSend, 25, 80);
      if (b) {
        b.click();
        return "button";
      }
      const box = composer();
      if (!box) return "";
      box.focus();
      try { box.dispatchEvent(new InputEvent("input", { bubbles: true })); } catch {}
      for (const type of ["keydown", "keypress", "keyup"]) {
        box.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      }
      return "enter";
    }
    const ask = (messages) =>
      Promise.race([
        new Promise((res) => {
          try {
            syncChatMood();
            chrome.runtime.sendMessage(
              { action: "suggest", messages, kind: "chat", subject: "", sender: "", platform: PLATFORM, pdf: null, auto: true, contact: IG ? igLabel() : chatNameFast(), tone: activeTone },
              (r) => res(chrome.runtime.lastError ? { error: "Extension error. Refresh this tab." } : r || { error: "No response" })
            );
          } catch { res({ error: "Extension was reloaded. Refresh this tab." }); }
        }),
        sleep(60000).then(() => ({ error: "Timed out" })),
      ]);

    // ---- toggle chips inside the unified Dock ----
    const autoTab = document.createElement("button");
    autoTab.textContent = "⚡ Auto: OFF";
    paintChip(autoTab, false);

    const chatTab = document.createElement("button");
    chatTab.textContent = "🎯 Chat: OFF";
    paintChip(chatTab, false);

    chipsRow.append(autoTab, chatTab);

    const chatOn = () => A.scope === "all" || A.chats.includes(chatName());
    const refreshButtons = () => {
      const locked = !isProUser;
      const on = !locked && A.on;
      const cOn = !locked && chatOn();
      setLedActive(on);
      paintBadge(on);
      autoTab.textContent = locked ? "⚡ Auto 🔒" : "⚡ Auto: " + (on ? "ON" : "OFF");
      paintChip(autoTab, on, locked);
      chatTab.textContent = locked ? "🎯 Chat 🔒" : "🎯 Chat: " + (cOn ? "ON" : "OFF");
      paintChip(chatTab, cOn, locked);
      chatTab.style.display = A.scope === "chats" ? "inline-flex" : "none";
    };
    const prevPlanRefresh = onPlanRefresh;
    onPlanRefresh = () => { prevPlanRefresh(); refreshButtons(); };

    // Turning Auto-reply ON also switches ON the chat that is open right now.
    const enableCurrent = () => {
      if (A.scope !== "chats") return;
      const name = chatName();
      if (!name || A.chats.includes(name)) return;
      A.chats = A.chats.concat(name);
      const m = lastMsg();
      if (m) handled[name] = m.id; // do not answer old messages
      delete paused[name];
      try { chrome.storage.local.set({ [K("autoChats")]: A.chats }); } catch {}
    };
    const diagnose = () => {
      const chat = lbl(chatName());
      const m = lastMsg();
      const who = !m ? "NOT FOUND" : (m.mine ? "from you" : "from them") + (m.group ? " (group, skipped)" : "");
      return "Check: chat = \"" + chat + "\", last text message = " + who + ", This chat = " + (chatOn() ? "ON" : "OFF") +
        ". Now send a NEW message to this chat from another phone; it will reply on its own.";
    };
    autoTab.addEventListener("click", () => {
      if (!isProUser) return toast("👑 Auto-Pilot (Auto-Reply) is a PRO feature! Open KYPER popup → Plan tab to unlock Pro.", true);
      A.on = !A.on;
      if (A.on) enableCurrent();
      try { chrome.storage.local.set({ [K("autoOn")]: A.on }); } catch {}
      refreshButtons();
      toast(A.on ? "Auto-reply is ON" + (IG ? " (" + (PLATFORM === "snapchat" ? "Snapchat" : "Instagram") + ": only chats you switch on, slower, max 10 per hour per chat)" : "") + ". Keep this tab open. It replies by itself to NEW messages in the chat open on screen." : "Auto-reply is OFF.");
      if (A.on) setTimeout(() => A.on && toast(diagnose()), 4000);
    });
    chatTab.addEventListener("click", () => {
      if (!isProUser) return toast("👑 Auto-Pilot (Auto-Reply) is a PRO feature! Open KYPER popup → Plan tab to unlock Pro.", true);
      const name = chatName();
      if (!name) return toast(IG ? "Could not tell which chat is open. Open one friend's chat first (the extension needs their name or chat id)." : "Open a chat first.", true);
      if (A.chats.includes(name)) A.chats = A.chats.filter((c) => c !== name);
      else {
        A.chats = A.chats.concat(name);
        const m = lastMsg();
        if (m) handled[name] = m.id;
        delete paused[name];
      }
      try { chrome.storage.local.set({ [K("autoChats")]: A.chats }); } catch {}
      refreshButtons();
      toast("Auto-reply for \"" + lbl(name) + "\": " + (A.chats.includes(name) ? "ON" : "OFF"));
    });

    // ---- settings ----
    const load = (d) => {
      if (!d || typeof d !== "object") return;
      const was = A.on;
      A.on = !!d[K("autoOn")];
      A.scope = !IG && d.autoScope === "all" ? "all" : "chats"; // Instagram: only chats you switch on (groups cannot be told apart reliably)
      A.chats = Array.isArray(d[K("autoChats")]) ? d[K("autoChats")] : [];
      A.min = num(d.autoMin, 1, 1, 300);
      A.max = Math.max(A.min, num(d.autoMax, 3, 1, 600));
      A.perHour = num(d.autoPerHour, 30, 1, 200);
      A.dayCap = num(d.autoDayCap, 300, 1, 1000);
      if (IG) { // Instagram is strict about bot-like behaviour: slower and lower limits than WhatsApp
        A.min = Math.max(A.min, 4);
        A.max = Math.max(A.max, A.min + 4);
        A.perHour = Math.min(A.perHour, 10);
        A.dayCap = Math.min(A.dayCap, 100);
      }
      if (ready && !was && A.on) enableCurrent(); // switched ON from the popup
      refreshButtons();
    };
    try {
      chrome.storage.local.get(CFG_KEYS.concat(K("autoLog"), "autoCfgV"), (d) => {
        d = d || {};
        if (d.autoCfgV !== 4) { // one-time move to the new defaults (30 per chat / hour, faster replies)
          const nv = { autoPerHour: 30, autoDayCap: 300, autoMin: 1, autoMax: 3, autoCfgV: 4 };
          Object.assign(d, nv);
          try { chrome.storage.local.set(nv); } catch {}
        }
        if (d[K("autoLog")] && typeof d[K("autoLog")] === "object") log = Object.assign({ day: "", count: 0, chats: {} }, d[K("autoLog")]);
        load(d);
        ready = true;
      });
      chrome.storage.onChanged.addListener((_, area) => {
        try { if (area === "local") chrome.storage.local.get(CFG_KEYS, load); } catch {}
      });
    } catch {}
    refreshButtons();

    const TYPING_SEL = IG ? 'footer, [role="textbox"], textarea, [contenteditable="true"]' : "footer";
    // If you type in a chat yourself, auto-reply stays out of it for 30 minutes.
    document.addEventListener("keydown", (e) => {
      if (!e.isTrusted || !e.target || !e.target.closest || !e.target.closest(TYPING_SEL)) return;
      paused[chatName()] = Date.now() + 30 * 60 * 1000;
    }, true);

    async function respond(chat, id) {
      pending = true;
      try {
        const msgs = SITE.read().messages;
        if (!msgs.length) { handled[chat] = id; return; }
        const wait = (A.min + Math.random() * (A.max - A.min)) * 1000;
        const [resp] = await Promise.all([ask(msgs), sleep(wait)]);

        // Re-check everything after the wait: the world may have changed.
        if (!A.on) return;
        const m = lastMsg();
        if (chatName() !== chat || !m || m.id !== id) return; // new message / other chat: next tick decides
        handled[chat] = id;
        if ((paused[chat] || 0) > Date.now()) return;
        if (resp.error) return toast("Auto-reply failed: " + resp.error, true);
        if (/\[\[\s*HOLD\s*\]\]/i.test(String(resp.reply || ""))) {
          paused[chat] = Date.now() + 6 * 3600 * 1000;
          return toast("Auto-reply PAUSED in \"" + lbl(chat) + "\" for 6 hours: her last message needs YOU (she may have asked if this is a bot, said stop or seemed upset, said she is under 18, or shared something serious). Nothing was sent. Please reply yourself.", true);
        }
        const reply = String(resp.reply || "").trim().slice(0, 700);
        if (!reply) return toast("Auto-reply: the AI sent an EMPTY reply in \"" + lbl(chat) + "\" (model problem, not a rule). Try again, or check the model / API key in the popup.", true);
        const block = capsBlock(chat);
        if (block) return toast("Auto-reply stopped in \"" + lbl(chat) + "\": " + block + ".", true);
        const box = composer();
        if (!box) return toast("Reply box not found.", true);
        if (boxText()) return; // you have a draft in the box, do not touch it

        // Type the reply ONCE and check it is not doubled before sending.
        const probe = norm(reply).slice(0, 24);
        const copies = () => { const t = norm(boxText()); return probe ? t.split(probe).length - 1 : 0; };
        let typed = false;
        for (let i = 0; i < 2 && !typed; i++) {
          await SITE.fill(reply);
          await sleep(150);
          if (copies() === 1) typed = true;
          else { // empty or doubled: clear the box and try again
            const b = composer();
            if (b) { b.focus(); document.execCommand("selectAll", false, null); document.execCommand("delete", false, null); }
            await sleep(120);
          }
        }
        if (!typed) {
          const b = composer();
          if (b) { b.focus(); document.execCommand("selectAll", false, null); document.execCommand("delete", false, null); }
          return toast("Auto-reply could not type the reply cleanly in \"" + lbl(chat) + "\", so nothing was sent.", true);
        }
        if (chatName() !== chat) return;
        const how = await sendNow();
        const cleared = await waitFor(() => !boxText(), 20, 100); // wait until the box empties
        if (!how || !cleared) return toast("Reply was typed in \"" + lbl(chat) + "\" but could not be sent (Send button not found). Press Enter yourself.", true);
        recordSent(chat, reply);
        toast("Auto-replied to \"" + lbl(chat) + "\": " + reply);
      } catch (e) {
        toast("Auto-reply error: " + (e && e.message), true);
      } finally {
        pending = false;
      }
    }

    function tick() {
      try {
        const chat = chatName();
        if (chat !== lastShown) { lastShown = chat; refreshButtons(); }
        if (!ready || !isProUser || !A.on || pending) return;
        const m = lastMsg();
        if (!m) return why("no text messages found in this chat");
        const id = m.id;

        // First time we see a chat: just remember where it stands (never answer old messages).
        if (!(chat in handled)) {
          if (cand.chat === chat && cand.id === id) handled[chat] = id;
          else { cand.chat = chat; cand.id = id; }
          return;
        }
        if (handled[chat] === id) return;

        // New message just arrived: wait until the sender has been quiet for a moment (one reply per burst).
        if (seen.chat !== chat || seen.id !== id) { seen.chat = chat; seen.id = id; seen.at = Date.now(); }
        if (!m.mine && Date.now() - seen.at < QUIET) return;

        const reason =
          m.mine ? "last message is mine" :
          m.group ? "group chat" :
          !m.text ? "no text" :
          A.scope === "chats" && !A.chats.includes(chat) ? "This chat is OFF" :
          (paused[chat] || 0) > Date.now() ? "paused (you typed here)" : "";
        if (reason) { handled[chat] = id; return why("skipped: " + reason); }

        const block = capsBlock(chat);
        if (block) { handled[chat] = id; return toast("Auto-reply stopped in \"" + lbl(chat) + "\": " + block + ".", true); }

        why("replying in " + chat);
        respond(chat, id);
      } catch (e) { dbg("tick error", e); }
    }
    setInterval(tick, 400);
  }
})();
