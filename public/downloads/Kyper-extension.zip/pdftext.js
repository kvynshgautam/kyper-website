// Small PDF text extractor with no libraries. Used for providers that cannot read PDFs directly.
// Works on normal text PDFs (Flate / ASCII85 / ASCIIHex streams, object streams, ToUnicode maps).
// It cannot read scanned (photo) PDFs or password-protected PDFs.

function bin2str(u8) {
  let out = "";
  for (let i = 0; i < u8.length; i += 8192) out += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
  return out;
}
function str2bin(s) {
  const u = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255;
  return u;
}

async function pdfInflate(bytes) {
  let lastErr;
  // some files have 1-2 stray bytes after the compressed data, so retry with a shorter slice
  for (let cut = 0; cut <= 2; cut++) {
    try {
      const ds = new DecompressionStream("deflate");
      const buf = await new Response(new Blob([bytes.subarray(0, bytes.length - cut)]).stream().pipeThrough(ds)).arrayBuffer();
      return new Uint8Array(buf);
    } catch (e) { lastErr = e; }
  }
  throw lastErr;
}
function pdfAscii85(s) {
  s = s.replace(/\s/g, "");
  if (s.startsWith("<~")) s = s.slice(2);
  const end = s.indexOf("~>");
  if (end !== -1) s = s.slice(0, end);
  const out = [];
  let group = [];
  for (const ch of s) {
    if (ch === "z" && group.length === 0) { out.push(0, 0, 0, 0); continue; }
    group.push(ch.charCodeAt(0) - 33);
    if (group.length === 5) {
      let v = 0;
      for (const g of group) v = v * 85 + g;
      out.push((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255);
      group = [];
    }
  }
  if (group.length > 1) {
    const n = group.length;
    while (group.length < 5) group.push(84);
    let v = 0;
    for (const g of group) v = v * 85 + g;
    const b = [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255];
    out.push(...b.slice(0, n - 1));
  }
  return Uint8Array.from(out);
}
function pdfAsciiHex(s) {
  s = s.replace(/[^0-9a-fA-F]/g, "");
  if (s.length % 2) s += "0";
  const u = new Uint8Array(s.length / 2);
  for (let i = 0; i < u.length; i++) u[i] = parseInt(s.substr(i * 2, 2), 16);
  return u;
}

// returns the balanced << ... >> block that starts at or after idx
function pdfDictAt(str, idx) {
  const s = str.indexOf("<<", idx);
  if (s === -1) return "";
  let depth = 0;
  for (let i = s; i < str.length - 1; i++) {
    if (str[i] === "<" && str[i + 1] === "<") { depth++; i++; }
    else if (str[i] === ">" && str[i + 1] === ">") { depth--; i++; if (depth === 0) return str.slice(s, i + 1); }
  }
  return str.slice(s);
}

function hexToUni(h) {
  if (h.length <= 2) return String.fromCharCode(parseInt(h, 16));
  let r = "";
  for (let i = 0; i + 4 <= h.length; i += 4) r += String.fromCharCode(parseInt(h.substr(i, 4), 16));
  return r;
}
function parseCMap(t) {
  const map = new Map();
  let bytes = 1;
  const cs = t.match(/begincodespacerange\s*<([0-9a-fA-F]+)>/);
  if (cs) bytes = Math.max(1, Math.round(cs[1].length / 2));
  for (const b of t.matchAll(/beginbfchar([\s\S]*?)endbfchar/g)) {
    for (const m of b[1].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>/g)) map.set(parseInt(m[1], 16), hexToUni(m[2]));
  }
  for (const b of t.matchAll(/beginbfrange([\s\S]*?)endbfrange/g)) {
    for (const m of b[1].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(<[0-9a-fA-F]+>|\[[^\]]*\])/g)) {
      const lo = parseInt(m[1], 16), hi = parseInt(m[2], 16);
      if (hi - lo > 70000) continue;
      if (m[3][0] === "[") {
        const arr = [...m[3].matchAll(/<([0-9a-fA-F]+)>/g)].map((x) => x[1]);
        for (let c = lo; c <= hi && c - lo < arr.length; c++) map.set(c, hexToUni(arr[c - lo]));
      } else {
        const dst = m[3].slice(1, -1);
        const base = hexToUni(dst);
        for (let c = lo; c <= hi; c++) {
          const last = base.charCodeAt(base.length - 1) + (c - lo);
          map.set(c, base.slice(0, -1) + String.fromCharCode(last));
        }
      }
    }
  }
  return { map, bytes };
}

function* pdfTokens(c) {
  let i = 0;
  const n = c.length;
  const stop = /[\s\/\[\]<>()%]/;
  while (i < n) {
    const ch = c[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === "%") { while (i < n && c[i] !== "\n" && c[i] !== "\r") i++; continue; }
    if (ch === "(") {
      let depth = 1, j = i + 1;
      const out = [];
      while (j < n && depth > 0) {
        const d = c[j];
        if (d === "\\") {
          const e = c[j + 1];
          j += 2;
          if (e === "n") out.push(10); else if (e === "r") out.push(13); else if (e === "t") out.push(9);
          else if (e === "b") out.push(8); else if (e === "f") out.push(12);
          else if (/[0-7]/.test(e)) {
            let oct = e;
            while (oct.length < 3 && j < n && /[0-7]/.test(c[j])) { oct += c[j]; j++; }
            out.push(parseInt(oct, 8) & 255);
          } else if (e === "\r" || e === "\n") { if (e === "\r" && c[j] === "\n") j++; }
          else out.push(e.charCodeAt(0));
          continue;
        }
        if (d === "(") depth++;
        else if (d === ")") { depth--; if (depth === 0) { j++; break; } }
        out.push(d.charCodeAt(0));
        j++;
      }
      yield { t: "s", v: Uint8Array.from(out) };
      i = j;
      continue;
    }
    if (ch === "<") {
      if (c[i + 1] === "<") { yield { t: "d<" }; i += 2; continue; }
      let e = c.indexOf(">", i);
      if (e === -1) e = n;
      yield { t: "s", v: pdfAsciiHex(c.slice(i + 1, e)) };
      i = e + 1;
      continue;
    }
    if (ch === ">") { i += c[i + 1] === ">" ? 2 : 1; yield { t: "d>" }; continue; }
    if (ch === "[") { yield { t: "[" }; i++; continue; }
    if (ch === "]") { yield { t: "]" }; i++; continue; }
    if (ch === "/") {
      let j = i + 1;
      while (j < n && !stop.test(c[j])) j++;
      yield { t: "n", v: c.slice(i + 1, j) };
      i = j;
      continue;
    }
    let j = i;
    while (j < n && !stop.test(c[j])) j++;
    if (j === i) { i++; continue; }
    const w = c.slice(i, j);
    i = j;
    if (/^[+-]?(\d+\.?\d*|\.\d+)$/.test(w)) yield { t: "num", v: parseFloat(w) };
    else yield { t: "op", v: w };
  }
}

async function extractPdfText(bytes, maxChars = 30000) {
  const s = bin2str(bytes);
  if (!s.startsWith("%PDF")) throw new Error("This file does not look like a PDF.");
  if (/\/Encrypt\s/.test(s)) throw new Error("This PDF is password protected.");

  // ---- 1. find all objects ----
  const objs = new Map();
  const re = /(\d+)\s+(\d+)\s+obj\b/g;
  let m;
  while ((m = re.exec(s))) {
    const num = +m[1];
    const bodyStart = re.lastIndex;
    const sIdx = s.indexOf("stream", bodyStart);
    const eIdx = s.indexOf("endobj", bodyStart);
    if (sIdx !== -1 && (eIdx === -1 || sIdx < eIdx) && s.slice(bodyStart, sIdx).includes(">>")) {
      const dict = s.slice(bodyStart, sIdx);
      let ds = sIdx + 6;
      if (s[ds] === "\r") ds++;
      if (s[ds] === "\n") ds++;
      let end = s.indexOf("endstream", ds);
      if (end === -1) end = s.length;
      const lm = dict.match(/\/Length\s+(\d+)(?:\s+(\d+)\s+R)?/);
      let exact = false;
      if (lm && lm[2] === undefined) {
        const len = +lm[1];
        if (/^\s*endstream/.test(s.slice(ds + len, ds + len + 12))) { end = ds + len; exact = true; }
      }
      if (!exact) {
        // length was indirect or wrong: drop the line break that sits before "endstream"
        if (s[end - 1] === "\n") end--;
        if (s[end - 1] === "\r") end--;
      }
      objs.set(num, { dict, raw: bytes.subarray(ds, end) });
      re.lastIndex = end;
    } else {
      const e = eIdx === -1 ? s.length : eIdx;
      objs.set(num, { dict: s.slice(bodyStart, e) });
      re.lastIndex = e;
    }
  }
  if (!objs.size) throw new Error("Could not read this PDF.");

  // ---- 2. decode streams ----
  const cache = new Map();
  async function streamData(num) {
    if (cache.has(num)) return cache.get(num);
    const o = objs.get(num);
    let data = null;
    if (o && o.raw) {
      const fm = o.dict.match(/\/Filter\s*(\[[^\]]*\]|\/\w+)/);
      const filters = fm ? [...fm[1].matchAll(/\/(\w+)/g)].map((x) => x[1]) : [];
      data = o.raw;
      try {
        for (const f of filters) {
          if (f === "FlateDecode" || f === "Fl") data = await pdfInflate(data);
          else if (f === "ASCII85Decode" || f === "A85") data = pdfAscii85(bin2str(data));
          else if (f === "ASCIIHexDecode" || f === "AHx") data = pdfAsciiHex(bin2str(data));
          else { data = null; break; }
        }
      } catch { data = null; }
    }
    cache.set(num, data);
    return data;
  }

  // ---- 3. unpack object streams ----
  for (const [num, o] of [...objs]) {
    if (!o.raw || !/\/Type\s*\/ObjStm/.test(o.dict)) continue;
    const data = await streamData(num);
    if (!data) continue;
    const t = bin2str(data);
    const N = +(o.dict.match(/\/N\s+(\d+)/) || [])[1];
    const first = +(o.dict.match(/\/First\s+(\d+)/) || [])[1];
    if (!N || !first) continue;
    const nums = t.slice(0, first).trim().split(/\s+/).map(Number);
    for (let k = 0; k < N; k++) {
      const on = nums[k * 2], off = nums[k * 2 + 1];
      const nextOff = k + 1 < N ? nums[(k + 1) * 2 + 1] : t.length - first;
      if (!objs.has(on)) objs.set(on, { dict: t.slice(first + off, first + nextOff) });
    }
  }

  // ---- 4. fonts ----
  const fontCache = new Map();
  async function loadFont(num) {
    if (fontCache.has(num)) return fontCache.get(num);
    const o = objs.get(num);
    const info = { cmap: null, unreadable: false };
    if (o) {
      const tu = o.dict.match(/\/ToUnicode\s+(\d+)\s+\d+\s+R/);
      if (tu) {
        const d = await streamData(+tu[1]);
        if (d) info.cmap = parseCMap(bin2str(d));
      }
      if (!info.cmap && /\/Subtype\s*\/Type0/.test(o.dict)) info.unreadable = true;
    }
    fontCache.set(num, info);
    return info;
  }

  // ---- 5. page order ----
  const kidsOf = (num) => {
    const o = objs.get(num);
    if (!o) return [];
    const km = o.dict.match(/\/Kids\s*\[([^\]]*)\]/);
    return km ? [...km[1].matchAll(/(\d+)\s+\d+\s+R/g)].map((x) => +x[1]) : [];
  };
  const isPage = (num) => /\/Type\s*\/Page(?![a-zA-Z])/.test((objs.get(num) || {}).dict || "");
  let pages = [];
  const walk = (num, depth = 0) => {
    if (depth > 30) return;
    if (isPage(num)) { pages.push(num); return; }
    for (const k of kidsOf(num)) walk(k, depth + 1);
  };
  let rootNum = null;
  for (const [num, o] of objs) {
    if (/\/Type\s*\/Catalog/.test(o.dict)) {
      const pm = o.dict.match(/\/Pages\s+(\d+)\s+\d+\s+R/);
      if (pm) rootNum = +pm[1];
    }
  }
  if (rootNum) walk(rootNum);
  if (!pages.length) pages = [...objs.keys()].filter(isPage).sort((a, b) => a - b);
  if (!pages.length) throw new Error("No pages found in this PDF.");

  function fontMapFor(pageNum) {
    let num = pageNum;
    for (let hop = 0; hop < 12 && num; hop++) {
      const o = objs.get(num);
      if (!o) break;
      let res = "";
      const rm = o.dict.match(/\/Resources\s*(\d+)\s+\d+\s+R/);
      if (rm) res = (objs.get(+rm[1]) || {}).dict || "";
      else {
        const idx = o.dict.indexOf("/Resources");
        if (idx !== -1) res = pdfDictAt(o.dict, idx);
      }
      if (res) {
        let fontDict = "";
        const fm = res.match(/\/Font\s*(\d+)\s+\d+\s+R/);
        if (fm) fontDict = (objs.get(+fm[1]) || {}).dict || "";
        else {
          const fi = res.indexOf("/Font");
          if (fi !== -1) fontDict = pdfDictAt(res, fi);
        }
        const map = {};
        for (const x of fontDict.matchAll(/\/([^\s\/\[\]<>()]+)\s+(\d+)\s+\d+\s+R/g)) map[x[1]] = +x[2];
        return map;
      }
      const pm = o.dict.match(/\/Parent\s+(\d+)\s+\d+\s+R/);
      num = pm ? +pm[1] : 0;
    }
    return {};
  }

  function decodeShown(bytesIn, font) {
    if (font && font.cmap) {
      let out = "";
      if (font.cmap.bytes >= 2) {
        for (let i = 0; i + 1 < bytesIn.length; i += 2) out += font.cmap.map.get((bytesIn[i] << 8) | bytesIn[i + 1]) ?? "";
      } else {
        for (const b of bytesIn) out += font.cmap.map.get(b) ?? (b >= 32 ? String.fromCharCode(b) : "");
      }
      return out;
    }
    if (font && font.unreadable) return "";
    let out = "";
    for (const b of bytesIn) if ((b >= 32 && b < 127) || b >= 160) out += String.fromCharCode(b);
    return out;
  }

  // ---- 6. read each page ----
  let result = "";
  let pageNo = 0;
  for (const pn of pages) {
    pageNo++;
    const po = objs.get(pn);
    const cm = po.dict.match(/\/Contents\s*(\[[^\]]*\]|\d+\s+\d+\s+R)/);
    if (!cm) continue;
    const refs = [...cm[1].matchAll(/(\d+)\s+\d+\s+R/g)].map((x) => +x[1]);
    let content = "";
    for (const r of refs) {
      const d = await streamData(r);
      if (d) content += bin2str(d) + "\n";
    }
    if (!content) continue;
    const fontNums = fontMapFor(pn);
    let font = null;
    let text = "";
    let stack = [];
    let arr = null;
    let lastY = null;
    const nl = () => { if (text && !text.endsWith("\n")) text += "\n"; };
    const sp = () => { if (text && !/[\s]$/.test(text)) text += " "; };
    for (const tk of pdfTokens(content)) {
      if (tk.t === "[") { arr = []; continue; }
      if (tk.t === "]") { if (arr) stack.push({ t: "arr", v: arr }); arr = null; continue; }
      if (arr) { if (tk.t === "s" || tk.t === "num") arr.push(tk); continue; }
      if (tk.t !== "op") { stack.push(tk); if (stack.length > 40) stack.shift(); continue; }
      const op = tk.v;
      const top = stack[stack.length - 1];
      if (op === "Tf") {
        const nameTok = stack[stack.length - 2];
        if (nameTok && nameTok.t === "n" && fontNums[nameTok.v] !== undefined) font = await loadFont(fontNums[nameTok.v]);
        else font = null;
      } else if (op === "Tj") { if (top && top.t === "s") text += decodeShown(top.v, font); }
      else if (op === "'" || op === '"') { nl(); if (top && top.t === "s") text += decodeShown(top.v, font); }
      else if (op === "TJ") {
        if (top && top.t === "arr") {
          for (const it of top.v) {
            if (it.t === "s") text += decodeShown(it.v, font);
            else if (it.v < -200) sp();
          }
        }
      } else if (op === "Td" || op === "TD") {
        const ty = stack[stack.length - 1], tx = stack[stack.length - 2];
        if (ty && ty.t === "num") {
          if (ty.v !== 0) nl(); else if (tx && tx.t === "num" && tx.v > 0) sp();
        }
      } else if (op === "T*") nl();
      else if (op === "Tm") {
        const y = stack[stack.length - 1];
        if (y && y.t === "num") {
          if (lastY !== null && Math.abs(y.v - lastY) > 1) nl(); else sp();
          lastY = y.v;
        }
      } else if (op === "ET") nl();
      stack = [];
    }
    text = text.split("\n").map((l) => l.replace(/[ \t]+/g, " ").trim()).filter(Boolean).join("\n");
    if (text) result += (result ? "\n\n" : "") + `--- Page ${pageNo} ---\n` + text;
    if (result.length >= maxChars) break;
  }

  result = result.slice(0, maxChars).trim();
  const letters = (result.match(/[A-Za-z\u0900-\u097F]/g) || []).length;
  if (letters < 20) throw new Error("No readable text found. This PDF may be scanned (photos) or use unsupported fonts.");
  return result;
}

if (typeof module !== "undefined") module.exports = { extractPdfText };
